// [UNITY-SKILL:SPRITEATLAS]
// [TYPE:PREBUILD]
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.U2D;
using UnityEngine;
using UnityEngine.U2D;

public sealed class CharacterAtlasBuilder : IPreprocessBuildWithReport
{
    public int callbackOrder => -100;
    public void OnPreprocessBuild(BuildReport report) => Generate();

    [MenuItem("Game/Characters/Generate Shared Atlases")]
    public static void Generate()
    {
        EditorSettings.spritePackerMode = SpritePackerMode.SpriteAtlasV2;
        GenerateGroup("Body", new[] { "head", "hands", "shadow" });
        GenerateGroup("Clothes", new[] { "torso", "fararm", "neararm", "legs" });
        GenerateGroup("Greatsword", new[] { "weapon" });
        if (File.Exists(CommonRigLabBuilder.MotionsPath)) CommonRigLabBuilder.GenerateAtlas();
        GenerateAzureVanguard();
    }

    public static void GenerateAzureVanguard()
    {
        const string root = "Assets/Art/Characters/AzureVanguard/";
        var sprites = AssetDatabase.LoadAllAssetsAtPath(root + "azure-vanguard-parts.png").OfType<Sprite>().Cast<Object>().ToArray();
        if (sprites.Length == 0) return;
        string path = root + "AzureVanguard.spriteatlasv2";
        var atlas = new SpriteAtlasAsset(); atlas.Add(sprites);
        SpriteAtlasAsset.Save(atlas, path); AssetDatabase.ImportAsset(path);
        var importer = (SpriteAtlasImporter)AssetImporter.GetAtPath(path); importer.includeInBuild = true;
        var packing = importer.packingSettings; packing.enableRotation = packing.enableTightPacking = false; packing.padding = 4; importer.packingSettings = packing;
        var texture = importer.textureSettings; texture.filterMode = FilterMode.Point; texture.generateMipMaps = false; texture.readable = false; importer.textureSettings = texture;
        var platform = importer.GetPlatformSettings("DefaultTexturePlatform"); platform.maxTextureSize = 1024; platform.textureCompression = TextureImporterCompression.Uncompressed;
        importer.SetPlatformSettings(platform); importer.SaveAndReimport();
    }

    private static void GenerateGroup(string name, string[] sheets)
    {
        const string source = CharacterContentBuilder.Root + "Sheets/";
        string path = CharacterContentBuilder.Root + "Atlases/" + name + ".spriteatlasv2";
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        // Rebuild only our generated assets. Never collect unrelated project/package sprites.
        var packables = sheets.SelectMany(s => AssetDatabase.LoadAllAssetsAtPath(source + s + ".png"))
            .OfType<Sprite>().Cast<Object>().ToArray();
        if (packables.Length == 0) throw new BuildFailedException("Missing character sprites: " + name);
        var atlas = new SpriteAtlasAsset(); atlas.Add(packables);
        SpriteAtlasAsset.Save(atlas, path); AssetDatabase.ImportAsset(path);
        var importer = (SpriteAtlasImporter)AssetImporter.GetAtPath(path);
        importer.includeInBuild = true;
        var packing = importer.packingSettings;
        packing.enableRotation = false; packing.enableTightPacking = false; packing.padding = 4;
        importer.packingSettings = packing;
        var texture = importer.textureSettings;
        texture.filterMode = FilterMode.Point; texture.generateMipMaps = false; texture.readable = false;
        importer.textureSettings = texture;
        var platform = importer.GetPlatformSettings("DefaultTexturePlatform");
        platform.maxTextureSize = 2048; platform.textureCompression = TextureImporterCompression.Uncompressed;
        importer.SetPlatformSettings(platform); importer.SaveAndReimport();
    }
}
