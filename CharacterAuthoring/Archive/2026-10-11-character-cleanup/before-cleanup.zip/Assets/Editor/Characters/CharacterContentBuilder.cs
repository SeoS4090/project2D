using System;
using System.IO;
using System.Linq;
using Game.Characters;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.U2D.Sprites;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class CharacterContentBuilder
{
    public const string Root = "Assets/Art/Characters/Assembly/";
    public const string CatalogPath = Root + "TrainingCatalog.asset";
    public const string DraftRoot = "CharacterAuthoring/Drafts/";
    public const string PublishedRoot = "CharacterAuthoring/Published/";

    [MenuItem("Game/Characters/Generate Training Catalog")]
    public static CharacterCatalog Generate()
    {
        var motion = AssetDatabase.LoadAssetAtPath<TrainingHeroAnimationSet>(TrainingMannequinInstaller.SetPath);
        if (motion == null) throw new InvalidOperationException("마네킹 모션을 먼저 임포트하세요.");
        string signature = AssetDatabase.GetAssetDependencyHash(TrainingMannequinInstaller.SetPath).ToString();
        foreach (string sheet in new[] { "head", "torso", "fararm", "neararm", "legs", "hands", "shadow", "weapon" })
            signature += AppearanceValidation.Hash(Convert.ToBase64String(File.ReadAllBytes(Root + "Sheets/" + sheet + ".png")));
        string hash = AppearanceValidation.Hash("assembly-import-v2\n" + signature);
        var existing = AssetDatabase.LoadAssetAtPath<CharacterCatalog>(CatalogPath);
        if (existing != null)
        {
            if (existing.sourceHash != hash) throw new InvalidOperationException("원본이 바뀌었습니다. 기존 발행본을 덮어쓰지 말고 새 카탈로그 버전으로 이관하세요.");
            return existing;
        }
        Directory.CreateDirectory(Root);
        var sheets = new System.Collections.Generic.Dictionary<string, Sprite[]>();
        foreach (string sheet in new[] { "head", "torso", "fararm", "neararm", "legs", "hands", "shadow", "weapon" })
            sheets[sheet] = ImportSheet(sheet, motion.frames.Length);
        var catalog = ScriptableObject.CreateInstance<CharacterCatalog>();
        catalog.sourceHash = hash; catalog.version = "training-" + hash.Substring(0, 12);
        catalog.motion = motion; catalog.frameCount = motion.frames.Length;
        catalog.releaseBlockers = new[]
        {
            "16각도/포즈별 팔·손·소매와 그립 매핑 미제작",
            "최종 의상 디자인·필수 기절 모션 미제작 (현재 마네킹 레이어/시험 팔레트)",
            "CV01–CV16 전체 출하 검증 미완료"
        };
        catalog.palettes = new[]
        {
            new VisualPalette { id = "neutral", color = Color.white },
            new VisualPalette { id = "cool", color = new Color(.67f, .82f, 1f) },
            new VisualPalette { id = "warm", color = new Color(1f, .79f, .58f) }
        };
        catalog.parts = new[]
        {
            new VisualPart { id = "part.mannequin", slot = AppearanceSlot.Body,
                pieces = new[]
                {
                    Piece("head", "", motion, sheets["head"], f => f.weaponBehind ? 3 : 2),
                    Piece("hands", "", motion, sheets["hands"], f => 5),
                    Piece("shadow", "", motion, sheets["shadow"], f => -4)
                } },
            new VisualPart { id = "part.baseline-upper", slot = AppearanceSlot.Upper,
                paletteIds = new[] { "neutral", "cool", "warm" }, pieces = new[] {
                    Piece("torso", "", motion, sheets["torso"], f => 0, false, true),
                    Piece("fararm", "", motion, sheets["fararm"], f => 1, false, true),
                    Piece("neararm", "", motion, sheets["neararm"], f => f.weaponBehind ? 2 : 3, false, true) } },
            new VisualPart { id = "part.baseline-lower", slot = AppearanceSlot.Lower,
                paletteIds = new[] { "neutral", "cool", "warm" },
                pieces = new[] { Piece("legs", "", motion, sheets["legs"], f => -2, true, true) } },
            new VisualPart { id = "weapon.blockout-greatsword", slot = AppearanceSlot.Weapon, weaponFamily = "greatsword",
                pieces = new[] { Piece("blade", "", motion, sheets["weapon"], f => f.weaponBehind ? -1 : 4) } }
        };
        catalog.baseline = new AppearanceRecipe
        {
            catalogVersion = catalog.version,
            selections = catalog.parts.Select(p => new PartSelection { slot = p.slot, partId = p.id }).ToArray()
        };
        var errors = AppearanceValidation.Check(catalog, catalog.baseline);
        if (errors.Count != 0) { UnityEngine.Object.DestroyImmediate(catalog); throw new InvalidDataException(string.Join("\n", errors)); }
        catalog.baseline.dependencyHash = AppearanceValidation.Fingerprint(catalog, catalog.baseline);
        AssetDatabase.CreateAsset(catalog, CatalogPath); AssetDatabase.SaveAssets();
        CharacterAtlasBuilder.Generate();
        return catalog;
    }

    private static VisualPiece Piece(string id, string group, TrainingHeroAnimationSet motion,
        Sprite[] sprites, Func<TrainingHeroAnimationSet.Frame, int> order,
        bool lower = false, bool tint = false) => new VisualPiece
        {
            id = id, hideGroup = group, lowerBody = lower, tintable = tint,
            frames = sprites, orders = motion.frames.Select(order).ToArray()
        };

    private static Sprite[] ImportSheet(string name, int count)
    {
        string path = Root + "Sheets/" + name + ".png";
        AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
        var importer = (TextureImporter)AssetImporter.GetAtPath(path);
        importer.textureType = TextureImporterType.Sprite; importer.spriteImportMode = SpriteImportMode.Multiple;
        importer.spritePixelsPerUnit = 32; importer.filterMode = FilterMode.Point;
        importer.mipmapEnabled = false; importer.textureCompression = TextureImporterCompression.Uncompressed;
        importer.maxTextureSize = 4096; importer.npotScale = TextureImporterNPOTScale.None;
        var settings = new TextureImporterSettings(); importer.ReadTextureSettings(settings);
        settings.spriteMeshType = SpriteMeshType.FullRect; importer.SetTextureSettings(settings);
        importer.SaveAndReimport();
        var factories = new SpriteDataProviderFactories(); factories.Init();
        var provider = factories.GetSpriteEditorDataProviderFromObject(importer); provider.InitSpriteEditorDataProvider();
        var capabilities = provider.GetDataProvider<ISpriteFrameEditCapability>();
        if (capabilities == null) throw new InvalidOperationException("Sprite 편집 기능 확인 실패: " + path);
        var capability = capabilities.GetEditCapability();
        foreach (var required in new[] { EEditCapability.CreateAndDeleteSprite, EEditCapability.EditSpriteRect, EEditCapability.EditPivot, EEditCapability.EditSpriteName })
            if (!capability.HasCapability(required)) throw new InvalidOperationException("지원하지 않는 Sprite 편집: " + required);
        var oldIds = provider.GetSpriteRects().ToDictionary(r => r.name, r => r.spriteID);
        var texture = new Texture2D(2, 2); texture.LoadImage(File.ReadAllBytes(path));
        var pixels = texture.GetPixels32(); int width = texture.width, height = texture.height;
        UnityEngine.Object.DestroyImmediate(texture);
        var rects = new SpriteRect[count];
        for (int i = 0; i < count; i++)
        {
            int x0 = i % 16 * 128, y0 = height - (i / 16 + 1) * 128;
            int minX = 128, minY = 128, maxX = -1, maxY = -1;
            for (int y = 0; y < 128; y++) for (int x = 0; x < 128; x++)
                if (pixels[(y0 + y) * width + x0 + x].a != 0)
                { minX = Math.Min(minX, x); minY = Math.Min(minY, y); maxX = Math.Max(maxX, x); maxY = Math.Max(maxY, y); }
            if (maxX < 0) { minX = maxX = 64; minY = maxY = 24; }
            string spriteName = name + "_pose_" + i.ToString("D3");
            rects[i] = new SpriteRect { name = spriteName,
                spriteID = oldIds.TryGetValue(spriteName, out var id) ? id : GUID.Generate(),
                rect = new Rect(x0 + minX, y0 + minY, maxX - minX + 1, maxY - minY + 1),
                alignment = SpriteAlignment.Custom,
                pivot = new Vector2((64f - minX) / (maxX - minX + 1), (24f - minY) / (maxY - minY + 1)) };
        }
        provider.SetSpriteRects(rects);
        provider.GetDataProvider<ISpriteNameFileIdDataProvider>()?.SetNameFileIdPairs(rects.Select(r => new SpriteNameFileIdPair(r.name, r.spriteID)));
        provider.Apply(); importer.SaveAndReimport();
        return AssetDatabase.LoadAllAssetsAtPath(path).OfType<Sprite>().OrderBy(s => s.name, StringComparer.Ordinal).ToArray();
    }

    [MenuItem("Game/Characters/Attach To Training Player")]
    public static void Attach()
    {
        if (EditorApplication.isPlaying) throw new InvalidOperationException("편집 모드에서 연결하세요.");
        if (SceneManager.GetActiveScene().path != "Assets/Scenes/TrainingGround.unity")
            throw new InvalidOperationException("TrainingGround 씬을 먼저 여세요.");
        var view = UnityEngine.Object.FindFirstObjectByType<TrainingPlayerView>();
        if (view == null) throw new InvalidOperationException("훈련장 플레이어가 없습니다.");
        var catalog = Generate();
        if (view.AnimationSet != catalog.motion) throw new InvalidOperationException("훈련장 모션과 카탈로그가 다릅니다.");
        var appearance = view.GetComponent<CharacterAppearance>();
        if (appearance == null) appearance = Undo.AddComponent<CharacterAppearance>(view.gameObject);
        Undo.RecordObject(appearance, "Attach character catalog");
        var serialized = new SerializedObject(view);
        var originals = new[] { "bodyRenderer", "legsRenderer", "handsRenderer", "swordRenderer", "shadowRenderer", "effectsRenderer" }
            .Select(n => serialized.FindProperty(n).objectReferenceValue as SpriteRenderer).Where(r => r != null).ToArray();
        appearance.Configure(catalog, catalog.baseline, originals, originals[0].sharedMaterial);
        EditorUtility.SetDirty(appearance);
        EditorSceneManager.MarkSceneDirty(view.gameObject.scene);
        // Keep the user's existing scene edits; saving is left to the normal scene workflow.
    }

    public static string SafeName(string id)
    {
        if (string.IsNullOrWhiteSpace(id) || id.Length > 80 || id.Any(c => !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9') && c != '-' && c != '_' && c != '.'))
            throw new InvalidDataException("ID에는 영문·숫자·점·밑줄·하이픈만 사용할 수 있습니다.");
        if (id == "." || id == "..") throw new InvalidDataException("잘못된 ID");
        return id;
    }

    public static void SaveDraft(AppearanceDraft draft)
    {
        string path = DraftRoot + SafeName(draft.draftId) + ".json";
        Directory.CreateDirectory(DraftRoot);
        if (File.Exists(path))
        {
            var current = JsonUtility.FromJson<AppearanceDraft>(File.ReadAllText(path));
            if (current.schemaVersion != 1 || current.revision != draft.revision) throw new InvalidOperationException("초안 리비전 충돌. 다시 열거나 다른 ID로 저장하세요.");
        }
        else if (draft.revision != 0) throw new InvalidOperationException("초안 원본 파일이 없습니다.");
        var copy = JsonUtility.FromJson<AppearanceDraft>(JsonUtility.ToJson(draft)); copy.revision++;
        AtomicWrite(path, JsonUtility.ToJson(copy, true));
        draft.revision = copy.revision;
    }

    public static string Publish(CharacterCatalog catalog, AppearanceRecipe recipe, string reviewedHash, bool release)
    {
        if (Generate() != catalog) throw new InvalidOperationException("현재 원본과 연결된 카탈로그가 아닙니다.");
        var errors = AppearanceValidation.Check(catalog, recipe, release);
        if (errors.Count != 0) throw new InvalidDataException(string.Join("\n", errors));
        string hash = AppearanceValidation.Fingerprint(catalog, recipe);
        if (hash != reviewedHash) throw new InvalidOperationException("검사 이후 내용이 바뀌었습니다. 미리보기와 검사를 다시 실행하세요.");
        var copy = recipe.Copy(); copy.dependencyHash = hash;
        string directory = PublishedRoot + (release ? "Release/" : "Training/") + SafeName(copy.recipeId) + "/";
        Directory.CreateDirectory(directory);
        string snapshot = directory + copy.revision + ".json";
        if (File.Exists(snapshot)) throw new InvalidOperationException("이미 발행된 리비전입니다. 새 리비전으로 발행하세요.");
        string json = JsonUtility.ToJson(copy, true);
        // CreateNew provides collision protection; current pointer changes only after a complete readback.
        string staged = snapshot + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var stream = new FileStream(staged, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream)) { writer.Write(json); writer.Flush(); stream.Flush(true); }
            if (File.ReadAllText(staged) != json) throw new IOException("발행 파일 읽기 검증 실패");
            File.Move(staged, snapshot);
        }
        finally { if (File.Exists(staged)) File.Delete(staged); }
        var readback = JsonUtility.FromJson<AppearanceRecipe>(File.ReadAllText(snapshot));
        if (readback.dependencyHash != hash) throw new IOException("발행 파일 읽기 검증 실패");
        AtomicWrite(directory + "current.json", json);
        return snapshot;
    }

    private static void AtomicWrite(string path, string contents)
    {
        string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream)) { writer.Write(contents); writer.Flush(); stream.Flush(true); }
            if (File.ReadAllText(temporary) != contents) throw new IOException("저장 읽기 검증 실패");
            if (File.Exists(path)) File.Replace(temporary, path, path + ".bak"); else File.Move(temporary, path);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
}
