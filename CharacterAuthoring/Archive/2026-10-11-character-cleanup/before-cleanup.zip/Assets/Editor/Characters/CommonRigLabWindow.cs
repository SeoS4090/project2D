using System;
using System.Collections.Generic;
using Game.Characters;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public sealed class CommonRigLabWindow : EditorWindow
{
    private PreviewRenderUtility preview;
    private readonly List<CommonCharacterRig> actors = new List<CommonCharacterRig>();
    private double previous;
    private float elapsed;
    [MenuItem("Game/Characters/Common Rig/Open Comparison")]
    public static void Open() => GetWindow<CommonRigLabWindow>("공통 리그 비교");

    public void CreateGUI()
    {
        minSize = new Vector2(840, 640);
        AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/Editor/Characters/CommonRigLab.uxml").CloneTree(rootVisualElement);
        var motions = AssetDatabase.LoadAssetAtPath<CommonRigMotions>(CommonRigLabBuilder.MotionsPath);
        if (motions == null) { rootVisualElement.Q<Label>("diagnostics").text = "Generate Experiment를 먼저 실행하세요."; return; }
        var names = new List<string> { "아래", "위", "왼쪽", "오른쪽" };
        foreach (string name in new[] { "upperDirection", "lowerDirection" })
        { var field = rootVisualElement.Q<DropdownField>(name); field.choices = names; field.index = name == "upperDirection" ? 3 : 2; }
        var motion = rootVisualElement.Q<DropdownField>("motion"); motion.choices = new List<string> { "대기", "걷기", "대검 베기", "역베기", "강베기", "차지", "회전 공격" }; motion.index = 2;
        preview = new PreviewRenderUtility();
        preview.camera.orthographic = true; preview.camera.orthographicSize = 2.5f;
        preview.camera.transform.position = new Vector3(0, 1, -10);
        preview.camera.nearClipPlane = .1f; preview.camera.farClipPlane = 30;
        preview.camera.clearFlags = CameraClearFlags.SolidColor; preview.camera.backgroundColor = new Color(.078f, .125f, .16f);
        preview.camera.allowHDR = preview.camera.allowMSAA = false;
        int index = 0;
        foreach (string id in new[] { "blue-tunic", "bronze-armor" })
        {
            var go = Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(CommonRigLabBuilder.Root + id + ".prefab"));
            preview.AddSingleGO(go); go.transform.position = new Vector3(index++ == 0 ? -1.5f : 1.5f, 0, 0);
            actors.Add(go.GetComponent<CommonCharacterRig>());
        }
        previous = EditorApplication.timeSinceStartup;
        rootVisualElement.schedule.Execute(Tick).Every(16);
    }
    private void Tick()
    {
        if (preview == null || actors.Count != 2) return;
        var root = rootVisualElement;
        double now = EditorApplication.timeSinceStartup;
        if (root.Q<Toggle>("playing").value) elapsed += (float)(now - previous);
        previous = now;
        var motion = (RigUpperMotion)root.Q<DropdownField>("motion").index;
        float duration = actors[0].Motions.Upper(motion, 3).length;
        float phase = root.Q<Toggle>("playing").value ? Mathf.Repeat(elapsed / duration, 1) : root.Q<Slider>("time").value;
        foreach (var rig in actors)
        {
            if (root.Q<Toggle>("continuous").value)
            {
                float angle = root.Q<Slider>("angle").value * Mathf.Deg2Rad;
                rig.SampleContinuous(motion, new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)), root.Q<DropdownField>("lowerDirection").index,
                    phase * duration, phase * (root.Q<Toggle>("dash").value ? .2f : .8f), root.Q<Toggle>("walking").value, root.Q<Toggle>("dash").value);
            }
            else
            rig.Sample(motion, root.Q<DropdownField>("upperDirection").index, root.Q<DropdownField>("lowerDirection").index,
                phase * duration, phase * (root.Q<Toggle>("dash").value ? .2f : .8f), root.Q<Toggle>("walking").value,
                root.Q<Toggle>("dash").value, root.Q<Toggle>("snap").value);
        }
        root.Q<DropdownField>("upperDirection").SetEnabled(!root.Q<Toggle>("continuous").value);
        root.Q<Toggle>("snap").SetEnabled(!root.Q<Toggle>("continuous").value);
        root.Q<Slider>("angle").SetEnabled(root.Q<Toggle>("continuous").value);
        preview.BeginPreview(new Rect(0, 0, 320, 160), GUIStyle.none); preview.camera.Render();
        var texture = preview.EndPreview(); texture.filterMode = FilterMode.Point;
        root.Q<Image>("preview").image = texture;
        root.Q<Label>("diagnostics").text = $"동일 클립 / 서로 다른 외형 · 주손 오차 {actors[0].MainGripErrorPixels:F3}px · 보조손 오차 {actors[0].OffGripErrorPixels:F3}px\n" +
            "회전은 실제 Transform 회전입니다. 정수 보정은 루트 흔들림만 줄이며 회전 가장자리 모양을 없애지 않습니다.";
    }
    private void OnDisable()
    {
        preview?.Cleanup(); preview = null; actors.Clear();
    }
}
