using System;
using System.IO;
using System.Linq;
using Game.Characters;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UIElements;

public sealed class CharacterMakerWindow : EditorWindow
{
    private CharacterCatalog catalog;
    private AppearanceDraft draft;
    private string reviewedHash;
    private PreviewRenderUtility preview;
    private CharacterAppearance actor;
    private Material material;
    private double previousTime;
    private float elapsed;
    private bool closing;
    private const string UiRoot = "Assets/Editor/Characters/";

    [MenuItem("Game/Characters/Character Maker")]
    public static void Open() => GetWindow<CharacterMakerWindow>("캐릭터 제작");

    public void CreateGUI()
    {
        closing = false;
        minSize = new Vector2(820, 600);
        AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(UiRoot + "CharacterMaker.uxml").CloneTree(rootVisualElement);
        catalog = AssetDatabase.LoadAssetAtPath<CharacterCatalog>(CharacterContentBuilder.CatalogPath);
        if (catalog == null) { Message("Game > Characters > Generate Training Catalog를 먼저 실행하세요."); return; }
        draft = new AppearanceDraft { baseline = catalog.baseline.Copy() };
        draft.baseline.dependencyHash = null;
        var motion = rootVisualElement.Q<DropdownField>("motion");
        motion.choices = catalog.motion.clips.Select(c => c.name).ToList(); motion.value = "idle";
        var direction = rootVisualElement.Q<DropdownField>("direction");
        direction.choices = new System.Collections.Generic.List<string> { "아래", "위", "왼쪽", "오른쪽" }; direction.index = 0;
        rootVisualElement.Q<TextField>("recipeId").RegisterValueChangedCallback(e => { draft.baseline.recipeId = e.newValue; Invalidate(); });
        rootVisualElement.Q<IntegerField>("revision").RegisterValueChangedCallback(e => { draft.baseline.revision = e.newValue; Invalidate(); });
        Button("newDraft", () => { draft.draftId = CharacterContentBuilder.SafeName(rootVisualElement.Q<TextField>("draftId").value); draft.revision = 0; Message("새 초안입니다. 같은 ID의 기존 파일이 있으면 저장이 거부됩니다."); });
        Button("load", LoadDraft);
        Button("save", () => { draft.draftId = CharacterContentBuilder.SafeName(rootVisualElement.Q<TextField>("draftId").value); CharacterContentBuilder.SaveDraft(draft); Message("초안 저장 완료 · revision " + draft.revision); });
        Button("validate", ValidatePreview);
        Button("release", () => Message(string.Join("\n", AppearanceValidation.Check(catalog, Resolve(), true))));
        Button("publish", () => Message("훈련 발행 완료: " + CharacterContentBuilder.Publish(catalog, Resolve(), reviewedHash, false)));
        Button("apply", ApplyTraining);
        MakeSlots();
        preview = new PreviewRenderUtility();
        preview.camera.orthographic = true; preview.camera.orthographicSize = 2.3f;
        preview.camera.nearClipPlane = .1f; preview.camera.farClipPlane = 30;
        preview.camera.clearFlags = CameraClearFlags.SolidColor; preview.camera.backgroundColor = new Color(.08f, .13f, .18f);
        preview.camera.transform.position = new Vector3(0, 1.45f, -10);
        var go = new GameObject("Character maker preview", typeof(SortingGroup));
        preview.AddSingleGO(go);
        actor = go.AddComponent<CharacterAppearance>();
        material = new Material(Shader.Find("Sprites/Default"));
        actor.Configure(catalog, catalog.baseline, Array.Empty<SpriteRenderer>(), material);
        UpdatePreview();
        previousTime = EditorApplication.timeSinceStartup;
        rootVisualElement.schedule.Execute(Tick).Every(33);
        Message("훈련용 · " + catalog.frameCount + " 포즈 · 4방향\n의상은 마네킹 레이어 시험 자료이며 최종 디자인이 아닙니다.");
    }

    private void Button(string name, Action action) => rootVisualElement.Q<Button>(name).clicked += () =>
    { try { action(); } catch (Exception e) { Message(e.Message); } };
    private void Message(string text) => rootVisualElement.Q<Label>("diagnostics").text = text;
    private AppearanceRecipe Resolve() => AppearanceValidation.Resolve(draft);
    private void Invalidate() { reviewedHash = null; if (actor != null) UpdatePreview(); }

    private void MakeSlots()
    {
        var container = rootVisualElement.Q<VisualElement>("slots"); container.Clear();
        foreach (AppearanceSlot slot in Enum.GetValues(typeof(AppearanceSlot)))
        {
            var options = catalog.parts.Where(p => p.slot == slot).ToArray();
            var row = new VisualElement(); row.AddToClassList("slot"); container.Add(row);
            string label = new[] { "기본 몸체", "상의", "하의", "머리카락", "수염", "머리 장식", "등 장식", "실제 무기" }[(int)slot];
            if (options.Length == 0) { row.Add(new Label(label + " · 자료 없음 (선택 슬롯)")); continue; }
            var selected = Resolve().selections.FirstOrDefault(s => s.slot == slot);
            var choice = new DropdownField(label, options.Select(p => p.id).ToList(), Array.FindIndex(options, p => p.id == selected?.partId)); row.Add(choice);
            var part = options[Math.Max(0, choice.index)];
            var palette = new DropdownField("팔레트", part.paletteIds.ToList(), Math.Max(0, Array.IndexOf(part.paletteIds, selected?.paletteId))); row.Add(palette);
            choice.RegisterValueChangedCallback(e => { SetSelection(slot, options.First(p => p.id == e.newValue), "neutral"); MakeSlots(); });
            palette.RegisterValueChangedCallback(e => SetSelection(slot, options.First(p => p.id == choice.value), e.newValue));
            var inherit = new Button(() => { draft.overrides = draft.overrides.Where(s => s.slot != slot).ToArray(); Invalidate(); MakeSlots(); }) { text = "기준값 상속" }; row.Add(inherit);
        }
    }

    private void SetSelection(AppearanceSlot slot, VisualPart part, string palette)
    {
        draft.overrides = draft.overrides.Where(s => s.slot != slot).Concat(new[] { new PartSelection
        { slot = slot, partId = part.id, revision = part.revision, paletteId = palette } }).ToArray();
        Invalidate();
    }

    private async void UpdatePreview()
    {
        try { if (!await actor.ApplyAsync(Resolve()) && !closing) Message(actor.LastError); }
        catch (Exception e) { if (!closing) Message(e.Message); }
    }

    private void ValidatePreview()
    {
        var recipe = Resolve(); var errors = AppearanceValidation.Check(catalog, recipe);
        if (errors.Count != 0) { reviewedHash = null; Message(string.Join("\n", errors)); return; }
        if (actor == null || !actor.IsReady || AppearanceValidation.Fingerprint(catalog, actor.AppliedRecipe) != AppearanceValidation.Fingerprint(catalog, recipe))
            throw new InvalidOperationException("미리보기 준비가 끝난 뒤 다시 검사하세요.");
        reviewedHash = AppearanceValidation.Fingerprint(catalog, recipe);
        Message("훈련 조립 검사 통과. 현재 미리보기 조합으로 훈련 발행할 수 있습니다.\n정식 출하 검사는 별도입니다.");
    }

    private void LoadDraft()
    {
        string id = CharacterContentBuilder.SafeName(rootVisualElement.Q<TextField>("draftId").value);
        var loaded = JsonUtility.FromJson<AppearanceDraft>(File.ReadAllText(CharacterContentBuilder.DraftRoot + id + ".json"));
        var errors = AppearanceValidation.Check(catalog, AppearanceValidation.Resolve(loaded));
        if (errors.Count != 0) throw new InvalidDataException(string.Join("\n", errors));
        draft = loaded;
        rootVisualElement.Q<TextField>("recipeId").SetValueWithoutNotify(draft.baseline.recipeId);
        rootVisualElement.Q<IntegerField>("revision").SetValueWithoutNotify(draft.baseline.revision);
        MakeSlots(); Invalidate(); Message("초안 열기 완료 · revision " + draft.revision);
    }

    private async void ApplyTraining()
    {
        try
        {
            var recipe = Resolve();
            if (AppearanceValidation.Check(catalog, recipe).Count != 0) throw new InvalidOperationException("검사를 먼저 통과하세요.");
            if (!EditorApplication.isPlaying) CharacterContentBuilder.Attach();
            var view = UnityEngine.Object.FindFirstObjectByType<TrainingPlayerView>();
            var target = view != null ? view.GetComponent<CharacterAppearance>() : null;
            if (target == null || target.Catalog != catalog) throw new InvalidOperationException("동일 카탈로그의 훈련장 플레이어가 없습니다.");
            if (EditorApplication.isPlaying)
                Message(await target.ApplyAsync(recipe) ? "현재 훈련 세션에 적용했습니다." : target.LastError);
            else
            {
                Undo.RecordObject(target, "Apply training appearance");
                target.SetInitialRecipe(recipe); EditorUtility.SetDirty(target);
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(target.gameObject.scene);
                Message("훈련장 설정에 적용했습니다. 씬 저장 후 Play에서 확인하세요.");
            }
        }
        catch (Exception e) { Message(e.Message); }
    }

    private void Tick()
    {
        if (closing || actor == null || preview == null) return;
        double now = EditorApplication.timeSinceStartup;
        if (rootVisualElement.Q<Toggle>("playing").value) elapsed += (float)(now - previousTime);
        else elapsed = rootVisualElement.Q<Slider>("time").value;
        previousTime = now;
        var clip = catalog.motion.FindClip(rootVisualElement.Q<DropdownField>("motion").value);
        int frame = catalog.motion.SampleClip(rootVisualElement.Q<DropdownField>("direction").index, clip, elapsed);
        actor.RenderFrame(frame, frame);
        preview.BeginPreview(new Rect(0, 0, 512, 512), GUIStyle.none);
        preview.camera.Render();
        rootVisualElement.Q<Image>("preview").image = preview.EndPreview();
    }

    private void OnDisable()
    {
        closing = true; actor?.Release(); preview?.Cleanup(); preview = null; actor = null;
        if (material != null) DestroyImmediate(material);
    }
}
