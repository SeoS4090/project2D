using UnityEngine;

/// <summary>
/// Adapts combat state to the shared rig; retains sheet playback for legacy art review.
/// Visual timing reads combat state; it does not drive hit detection.
/// </summary>
public sealed class TrainingPlayerView : MonoBehaviour
{
    [SerializeField] private SpriteRenderer bodyRenderer;
    [SerializeField] private SpriteRenderer swordRenderer;
    [SerializeField] private Sprite[] bodyFrames = new Sprite[33];
    [SerializeField] private Sprite[] swordFrames = new Sprite[33];
    [SerializeField, Min(0.01f)] private float walkFrameSeconds = 0.12f;
    [SerializeField, Min(0f)] private float attackRecoverySeconds = 0.14f;
    [Header("Upgraded Aseprite animation (optional)")]
    [SerializeField] private TrainingHeroAnimationSet animationSet;
    [SerializeField] private SpriteRenderer shadowRenderer;
    [SerializeField] private SpriteRenderer effectsRenderer;
    [SerializeField] private SpriteRenderer legsRenderer;
    [SerializeField] private SpriteRenderer handsRenderer;
    public TrainingHeroAnimationSet AnimationSet => animationSet;
    public int CurrentFrame { get; private set; }
    public int CurrentLegFrame { get; private set; }
    public int CurrentDirection { get; private set; }
    public string CurrentMotion { get; private set; } = "idle";
    [SerializeField] private Game.Characters.CommonCharacterRig commonRig;
    public Game.Characters.CommonCharacterRig CommonRig => commonRig;
    public float RigPhase { get; private set; }

    private float locomotionElapsed;
    private bool wasMoving;
    private int previousDirection = -1;

    private float walkFrameTimer;
    private int walkFrame;
    private int facingDirection;
    private Vector2 lastAim = Vector2.down;
    private int observedAttackSequence;
    private int lockedAttackDirection;
    private float recoveryRemaining;
    private bool wasAttacking;
    private Game.Characters.CharacterAppearance appearance;

    private void Awake() => appearance = GetComponent<Game.Characters.CharacterAppearance>();

    public void BindCommonRig(Game.Characters.CommonCharacterRig rig)
    {
        commonRig = rig;
        var oldAssembly = GetComponent<Game.Characters.CharacterAppearance>();
        if (oldAssembly != null) oldAssembly.enabled = false;
        SetRigVisible(true);
    }

    private void SetRigVisible(bool visible)
    {
        if (commonRig == null) return;
        if (commonRig.gameObject.activeSelf != visible) commonRig.gameObject.SetActive(visible);
        if (bodyRenderer != null) bodyRenderer.enabled = !visible;
        if (swordRenderer != null) swordRenderer.enabled = !visible;
        if (shadowRenderer != null) shadowRenderer.enabled = !visible;
        if (effectsRenderer != null) effectsRenderer.enabled = !visible;
        if (legsRenderer != null) legsRenderer.enabled = !visible;
        if (handsRenderer != null) handsRenderer.enabled = !visible;
    }

    private static Game.Characters.RigUpperMotion RigMotion(string name) => name switch {
        "attack" => Game.Characters.RigUpperMotion.Slash,
        "attack_reverse" => Game.Characters.RigUpperMotion.Reverse,
        "attack_heavy" => Game.Characters.RigUpperMotion.Heavy,
        "charge" => Game.Characters.RigUpperMotion.Charge,
        "spin" => Game.Characters.RigUpperMotion.Spin,
        "walk" => Game.Characters.RigUpperMotion.Walk,
        _ => Game.Characters.RigUpperMotion.Idle };

    private void SetRigState(Vector2 move, Vector2 aim, bool pending, bool active, Vector2 attackDirection,
        float remaining, float windup, float activeTime, bool dashing, Vector2 dashDirection, float dashProgress,
        string attackClip, bool recovering, float recoveryProgress, bool charging, float chargeElapsed)
    {
        SetRigVisible(true);
        if (aim.sqrMagnitude > .001f) lastAim = aim.normalized;
        bool moving = move.sqrMagnitude > .001f;
        if (moving != wasMoving) locomotionElapsed = 0;
        wasMoving = moving;
        var facing = pending || active || recovering ? attackDirection : lastAim;
        if (facing.sqrMagnitude < .001f) facing = lastAim;
        var motion = RigMotion(charging ? "charge" : moving ? "walk" : "idle");
        CurrentMotion = charging ? "charge" : moving ? "walk" : "idle";
        float time = charging ? chargeElapsed : locomotionElapsed;
        RigPhase = 0;
        if (pending || active || recovering)
        {
            motion = RigMotion(attackClip);
            RigPhase = pending ? .32f * (1 - Mathf.Clamp01(remaining / Mathf.Max(.0001f, windup)))
                : active ? Mathf.Lerp(.32f, .70f, 1 - Mathf.Clamp01(remaining / Mathf.Max(.0001f, activeTime)))
                : Mathf.Lerp(.70f, 1, Mathf.Clamp01(recoveryProgress));
            time = RigPhase * commonRig.Motions.Upper(motion, 3).length;
            CurrentMotion = attackClip + (pending ? " / prepare" : active ? " / active" : " / recover");
        }
        int lower = Game.Characters.CommonCharacterRig.Direction(dashing ? dashDirection : moving ? move : facing);
        commonRig.SampleContinuous(motion, facing, lower, time,
            dashing ? Mathf.Clamp01(dashProgress) * commonRig.Motions.lowerDash[lower].length : locomotionElapsed, moving, dashing);
        CurrentDirection = commonRig.ViewDirection;
        locomotionElapsed += Time.deltaTime;
    }

    public void SetState(Vector2 move, Vector2 aim, bool attackPending, bool attackActive, Vector2 attackDirection, int attackSequence, float phaseRemaining, float windupDuration, float activeDuration,
        bool dashing = false, Vector2 dashDirection = default, float dashProgress = 0f,
        string attackClip = "attack", bool recovering = false, float recoveryProgress = 0f, bool charging = false, float chargeElapsed = 0f)
    {
        if (commonRig != null)
        {
            SetRigState(move, aim, attackPending, attackActive, attackDirection, phaseRemaining, windupDuration,
                activeDuration, dashing, dashDirection, dashProgress, attackClip, recovering, recoveryProgress, charging, chargeElapsed);
            return;
        }
        if (animationSet != null && animationSet.HasNamedClips)
        {
            SetDetailedState(move, aim, attackPending, attackActive, attackDirection, attackSequence,
                phaseRemaining, windupDuration, activeDuration, dashing, dashDirection, dashProgress,
                attackClip, recovering, recoveryProgress, charging, chargeElapsed);
            return;
        }
        if (animationSet != null)
        {
            SetUpgradedState(move, aim, attackPending, attackActive, attackDirection, attackSequence,
                phaseRemaining, windupDuration, activeDuration);
            return;
        }
        if (aim.sqrMagnitude > 0.001f) lastAim = aim.normalized;
        facingDirection = DirectionIndex(lastAim);
        if (attackSequence != observedAttackSequence)
        {
            observedAttackSequence = attackSequence;
            lockedAttackDirection = DirectionIndex(attackDirection);
            recoveryRemaining = 0f;
        }

        if (attackPending || attackActive)
        {
            wasAttacking = true;
            float attackElapsed = attackActive
                ? windupDuration + Mathf.Max(0f, activeDuration - phaseRemaining)
                : Mathf.Max(0f, windupDuration - phaseRemaining);
            ShowAttack(lockedAttackDirection, attackElapsed, windupDuration, activeDuration);
            return;
        }

        if (wasAttacking)
        {
            wasAttacking = false;
            recoveryRemaining = attackRecoverySeconds;
        }
        if (recoveryRemaining > 0f)
        {
            recoveryRemaining = Mathf.Max(0f, recoveryRemaining - Time.deltaTime);
            SetFrame(bodyRenderer, bodyFrames, IdleFrame(lockedAttackDirection));
            SetFrame(swordRenderer, swordFrames, AttackStart(lockedAttackDirection) + 2);
            SetWeaponOrder(lockedAttackDirection);
            return;
        }

        if (move.sqrMagnitude > 0.001f)
        {
            walkFrameTimer += Time.deltaTime;
            while (walkFrameTimer >= walkFrameSeconds)
            {
                walkFrameTimer -= walkFrameSeconds;
                walkFrame = (walkFrame + 1) % 4;
            }
            SetFrame(bodyRenderer, bodyFrames, WalkStart(facingDirection) + walkFrame);
        }
        else
        {
            walkFrameTimer = 0f;
            walkFrame = 0;
            SetFrame(bodyRenderer, bodyFrames, IdleFrame(facingDirection));
        }

        SetFrame(swordRenderer, swordFrames, IdleFrame(facingDirection));
        SetWeaponOrder(facingDirection);
    }

    public void ResetView()
    {
        walkFrameTimer = 0f;
        walkFrame = 0;
        facingDirection = 0;
        lastAim = Vector2.down;
        recoveryRemaining = 0f;
        wasAttacking = false;
        observedAttackSequence = 0;
        locomotionElapsed = 0f;
        wasMoving = false;
        previousDirection = -1;
        if (commonRig != null)
        {
            SetRigVisible(true);
            commonRig.SampleContinuous(Game.Characters.RigUpperMotion.Idle, Vector2.down, 0, 0, 0, false);
            CurrentMotion = "idle"; CurrentDirection = 0; RigPhase = 0;
            return;
        }
        if (animationSet != null)
        {
            if (animationSet.HasNamedClips)
            {
                PreviewClip("idle", 0, 0f);
                return;
            }
            ShowUpgradedFrame(0, 0);
            return;
        }
        SetFrame(bodyRenderer, bodyFrames, IdleFrame(facingDirection));
        SetFrame(swordRenderer, swordFrames, IdleFrame(facingDirection));
    }

    private void SetDetailedState(Vector2 move, Vector2 aim, bool pending, bool active,
        Vector2 attackDirection, int sequence, float remaining, float windup, float activeTime,
        bool dashing, Vector2 dashDirection, float dashProgress,
        string attackClip, bool recovering, float recoveryProgress, bool charging, float chargeElapsed)
    {
        if (aim.sqrMagnitude > 0.001f) lastAim = aim.normalized;
        facingDirection = DirectionIndex(lastAim);
        bool moving = move.sqrMagnitude > 0.001f;
        if (moving != wasMoving) locomotionElapsed = 0f;
        wasMoving = moving;
        TrainingHeroAnimationSet.Clip locomotion = animationSet.FindClip(moving ? "walk" : "idle");
        int upper = animationSet.SampleClip(facingDirection, locomotion, locomotionElapsed);
        int lowerDirection = moving ? DirectionIndex(move) : facingDirection;
        int lower = animationSet.SampleClip(lowerDirection, locomotion, locomotionElapsed);
        CurrentMotion = locomotion.name;
        if (sequence != observedAttackSequence)
        {
            observedAttackSequence = sequence;
            recoveryRemaining = 0f;
        }
        TrainingHeroAnimationSet.Clip attack = animationSet.FindClip(attackClip) ?? animationSet.FindClip("attack");
        if (charging)
        {
            upper = animationSet.SampleClip(facingDirection, animationSet.FindClip("charge"), chargeElapsed);
            CurrentMotion = "charge";
            if (!moving && !dashing) lower = upper;
        }
        if (pending || active)
        {
            wasAttacking = true;
            // Read execution direction too: a preparation shorter than one frame can skip its visual state.
            lockedAttackDirection = DirectionIndex(attackDirection);
            int first = attack.first + (pending ? 0 : attack.windupCount);
            int count = pending ? attack.windupCount : attack.activeCount;
            float phaseDuration = pending ? windup : activeTime;
            float progress = phaseDuration > 0f ? Mathf.Clamp01(1f - remaining / phaseDuration) : 1f;
            upper = animationSet.Sample(lockedAttackDirection, first, count,
                progress * animationSet.Duration(lockedAttackDirection, first, count), false);
            facingDirection = lockedAttackDirection;
            CurrentMotion = attack.name + (pending ? " / prepare" : " / active");
            if (!moving && !dashing) lower = upper;
        }
        else if (recovering)
        {
            int first = attack.first + attack.windupCount + attack.activeCount;
            int count = attack.count - attack.windupCount - attack.activeCount;
            lockedAttackDirection = DirectionIndex(attackDirection);
            float duration = animationSet.Duration(lockedAttackDirection, first, count);
            upper = animationSet.Sample(lockedAttackDirection, first, count, Mathf.Clamp01(recoveryProgress) * duration, false);
            facingDirection = lockedAttackDirection;
            CurrentMotion = attack.name + " / recover";
            if (!moving && !dashing) lower = upper;
        }
        if (dashing)
        {
            var dash = animationSet.FindClip("dash");
            int direction = DirectionIndex(dashDirection);
            lower = animationSet.Sample(direction, dash.first, dash.count,
                dashProgress * animationSet.Duration(direction, dash.first, dash.count), false);
            if (!pending && !active && !recovering && !charging)
            {
                upper = lower; facingDirection = direction; CurrentMotion = "dash";
            }
        }
        ShowDetailedFrame(upper, lower, facingDirection);
        locomotionElapsed += Time.deltaTime;
    }

    public void PreviewClip(string name, int direction, float elapsed)
    {
        if (commonRig != null)
        {
            bool supported = name == "idle" || name == "walk" || name == "attack" || name == "attack_reverse"
                || name == "attack_heavy" || name == "charge" || name == "spin" || name == "dash";
            SetRigVisible(supported);
            if (supported)
            {
                var aim = direction == 0 ? Vector2.down : direction == 1 ? Vector2.up : direction == 2 ? Vector2.left : Vector2.right;
                float progress = 0;
                var legacyClip = animationSet != null ? animationSet.FindClip(name) : null;
                if (legacyClip != null) progress = elapsed / Mathf.Max(.0001f, animationSet.Duration(direction, legacyClip.first, legacyClip.count));
                var motion = RigMotion(name);
                commonRig.SampleContinuous(motion, aim, direction, progress * commonRig.Motions.Upper(motion,3).length,
                    progress * (name == "dash" ? commonRig.Motions.lowerDash[direction].length : commonRig.Motions.lowerWalk[direction].length), name == "walk", name == "dash");
                CurrentMotion = "preview / " + name; CurrentDirection = direction;
                return;
            }
        }
        if (animationSet == null || !animationSet.HasNamedClips) return;
        var clip = animationSet.FindClip(name);
        if (clip == null) return;
        int index = animationSet.SampleClip(direction, clip, elapsed);
        CurrentMotion = "preview / " + name;
        ShowDetailedFrame(index, index, direction);
    }

    private void ShowDetailedFrame(int upperIndex, int lowerIndex, int direction)
    {
        var upper = animationSet.frames[upperIndex];
        CurrentFrame = upperIndex; CurrentLegFrame = lowerIndex; CurrentDirection = direction;
        if (appearance != null && appearance.isActiveAndEnabled && appearance.RenderFrame(upperIndex, lowerIndex)) return;
        if (bodyRenderer != null) bodyRenderer.sprite = upper.body;
        if (swordRenderer != null) swordRenderer.sprite = upper.sword;
        if (handsRenderer != null) handsRenderer.sprite = upper.hands;
        if (legsRenderer != null) legsRenderer.sprite = animationSet.frames[lowerIndex].legs;
        if (shadowRenderer != null) shadowRenderer.sprite = upper.shadow;
        if (effectsRenderer != null) effectsRenderer.sprite = upper.effects;
        if (bodyRenderer == null) return;
        int order = bodyRenderer.sortingOrder;
        if (shadowRenderer != null) shadowRenderer.sortingOrder = order - 4;
        if (legsRenderer != null) legsRenderer.sortingOrder = order - 2;
        if (swordRenderer != null) swordRenderer.sortingOrder = order + (upper.weaponBehind ? -1 : 1);
        if (handsRenderer != null) handsRenderer.sortingOrder = order + 2;
        if (effectsRenderer != null) effectsRenderer.sortingOrder = order + 3;
    }

    private void SetUpgradedState(Vector2 move, Vector2 aim, bool pending, bool active,
        Vector2 attackDirection, int sequence, float remaining, float windup, float activeTime)
    {
        if (aim.sqrMagnitude > 0.001f) lastAim = aim.normalized;
        facingDirection = DirectionIndex(lastAim);
        if (sequence != observedAttackSequence)
        {
            observedAttackSequence = sequence;
            lockedAttackDirection = DirectionIndex(attackDirection);
            recoveryRemaining = 0f;
        }
        if (pending || active)
        {
            wasAttacking = true;
            locomotionElapsed = 0f;
            int first = pending ? 10 : 12;
            float phaseDuration = pending ? windup : activeTime;
            float progress = phaseDuration > 0f ? Mathf.Clamp01(1f - remaining / phaseDuration) : 1f;
            // Normalize each visual phase to combat state. Animation never decides when damage lands.
            float elapsed = progress * animationSet.Duration(lockedAttackDirection, first, 2);
            ShowUpgradedFrame(animationSet.Sample(lockedAttackDirection, first, 2, elapsed, false), lockedAttackDirection);
            return;
        }
        float recovery = animationSet.Duration(lockedAttackDirection, 14, 2);
        if (wasAttacking)
        {
            wasAttacking = false;
            recoveryRemaining = recovery;
        }
        if (recoveryRemaining > 0f)
        {
            int frame = animationSet.Sample(lockedAttackDirection, 14, 2, recovery - recoveryRemaining, false);
            ShowUpgradedFrame(frame, lockedAttackDirection);
            recoveryRemaining = Mathf.Max(0f, recoveryRemaining - Time.deltaTime);
            return;
        }
        bool moving = move.sqrMagnitude > 0.001f;
        if (moving != wasMoving || facingDirection != previousDirection) locomotionElapsed = 0f;
        wasMoving = moving;
        previousDirection = facingDirection;
        int firstFrame = moving ? 4 : 0;
        int count = moving ? 6 : 4;
        ShowUpgradedFrame(animationSet.Sample(facingDirection, firstFrame, count, locomotionElapsed, true), facingDirection);
        locomotionElapsed += Time.deltaTime;
    }

    private void ShowUpgradedFrame(int index, int direction)
    {
        if (legsRenderer != null) legsRenderer.sprite = null;
        if (handsRenderer != null) handsRenderer.sprite = null;
        TrainingHeroAnimationSet.Frame frame = animationSet.frames[index];
        if (bodyRenderer != null) bodyRenderer.sprite = frame.body;
        if (swordRenderer != null) swordRenderer.sprite = frame.sword;
        if (shadowRenderer != null) shadowRenderer.sprite = frame.shadow;
        if (effectsRenderer != null) effectsRenderer.sprite = frame.effects;
        SetWeaponOrder(direction);
        if (bodyRenderer != null)
        {
            if (shadowRenderer != null) shadowRenderer.sortingOrder = bodyRenderer.sortingOrder - 2;
            if (effectsRenderer != null) effectsRenderer.sortingOrder = bodyRenderer.sortingOrder + 2;
        }
    }

    private void ShowAttack(int direction, float elapsed, float windup, float active)
    {
        int pose = elapsed < windup ? 0 : elapsed < windup + active ? 1 : 2;
        int frame = AttackStart(direction) + pose;
        SetFrame(bodyRenderer, bodyFrames, IdleFrame(direction));
        SetFrame(swordRenderer, swordFrames, frame);
        SetWeaponOrder(direction);
    }

    private void SetWeaponOrder(int direction)
    {
        if (swordRenderer == null || bodyRenderer == null) return;
        bool behind = direction == 1;
        swordRenderer.sortingOrder = behind ? bodyRenderer.sortingOrder - 1 : bodyRenderer.sortingOrder + 1;
    }

    private static void SetFrame(SpriteRenderer renderer, Sprite[] frames, int index)
    {
        if (renderer != null && frames != null && index >= 0 && index < frames.Length && frames[index] != null)
            renderer.sprite = frames[index];
    }

    private static int DirectionIndex(Vector2 direction)
    {
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y)) return direction.x < 0f ? 2 : 3;
        return direction.y > 0f ? 1 : 0;
    }

    private static int IdleFrame(int direction) => direction * 8;
    private static int WalkStart(int direction) => direction * 8 + 1;
    private static int AttackStart(int direction) => direction * 8 + 5;
}
