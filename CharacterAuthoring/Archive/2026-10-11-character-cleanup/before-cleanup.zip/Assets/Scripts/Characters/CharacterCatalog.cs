using System;
using UnityEngine;

namespace Game.Characters
{
    public enum AppearanceSlot { Body, Upper, Lower, Hair, Beard, Head, Back, Weapon }
    public enum SelectionMode { Inherit, Select, Empty }

    [Serializable] public sealed class PartSelection
    {
        public AppearanceSlot slot;
        public SelectionMode mode = SelectionMode.Select;
        public string partId;
        public int revision = 1;
        public string paletteId = "neutral";
        public PartSelection Copy() => (PartSelection)MemberwiseClone();
    }

    [Serializable] public sealed class AppearanceRecipe
    {
        public int schemaVersion = 1;
        public string recipeId = "recipe.training";
        public int revision = 1;
        public string catalogVersion;
        public string bodyId = "body.sd-mannequin";
        public string weaponFamily = "greatsword";
        public string dependencyHash;
        public PartSelection[] selections = Array.Empty<PartSelection>();
        public AppearanceRecipe Copy() => JsonUtility.FromJson<AppearanceRecipe>(JsonUtility.ToJson(this));
    }

    [Serializable] public sealed class AppearanceDraft
    {
        public int schemaVersion = 1;
        public string draftId = "training";
        public int revision;
        public AppearanceRecipe baseline;
        public PartSelection[] overrides = Array.Empty<PartSelection>();
    }

    [Serializable] public sealed class VisualPiece
    {
        public string id;
        public string hideGroup;
        public bool lowerBody;
        public bool tintable;
        public Sprite[] frames;
        public int[] orders;
    }

    [Serializable] public sealed class VisualPart
    {
        public string id;
        public int revision = 1;
        public string bodyId = "body.sd-mannequin";
        public AppearanceSlot slot;
        public string weaponFamily;
        // A baseline garment represented in the prototype body art, never an empty garment.
        public bool integratedBaseline;
        public string[] hideGroups = Array.Empty<string>();
        public string[] paletteIds = { "neutral" };
        public VisualPiece[] pieces = Array.Empty<VisualPiece>();
    }

    [Serializable] public sealed class VisualPalette
    {
        public string id;
        public Color color = Color.white;
    }

    /// <summary>Generated content. Runtime code never changes this shared asset.</summary>
    public sealed class CharacterCatalog : ScriptableObject
    {
        public string version;
        public string sourceHash;
        public string bodyId = "body.sd-mannequin";
        public int compatibilityVersion = 1;
        public float pixelsPerUnit = 32;
        public Vector2 footOrigin = new Vector2(64, 104);
        public int frameCount;
        public TrainingHeroAnimationSet motion;
        public bool trainingOnly = true;
        public string[] releaseBlockers = Array.Empty<string>();
        public VisualPart[] parts = Array.Empty<VisualPart>();
        public VisualPalette[] palettes = Array.Empty<VisualPalette>();
        public AppearanceRecipe baseline;

        public VisualPart Find(string id, int revision)
        {
            foreach (var part in parts)
                if (part != null && part.id == id && part.revision == revision) return part;
            return null;
        }
        public VisualPalette Palette(string id)
        {
            foreach (var palette in palettes) if (palette.id == id) return palette;
            return null;
        }
    }
}
