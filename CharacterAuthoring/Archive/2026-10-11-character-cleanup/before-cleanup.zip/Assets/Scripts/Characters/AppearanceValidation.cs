using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace Game.Characters
{
    public static class AppearanceValidation
    {
        public static bool Required(AppearanceSlot slot) => slot == AppearanceSlot.Body ||
            slot == AppearanceSlot.Upper || slot == AppearanceSlot.Lower || slot == AppearanceSlot.Weapon;

        public static AppearanceRecipe Resolve(AppearanceDraft draft)
        {
            if (draft == null || draft.schemaVersion != 1 || draft.baseline == null)
                throw new InvalidOperationException("지원하지 않는 초안 또는 기준 프리셋입니다.");
            var result = draft.baseline.Copy();
            var selected = new SortedDictionary<AppearanceSlot, PartSelection>();
            foreach (var entry in result.selections) selected.Add(entry.slot, entry.Copy());
            var visited = new HashSet<AppearanceSlot>();
            foreach (var entry in draft.overrides)
            {
                if (!visited.Add(entry.slot)) throw new InvalidOperationException("중복 슬롯: " + entry.slot);
                if (entry.mode == SelectionMode.Inherit) continue;
                if (entry.mode == SelectionMode.Empty)
                {
                    if (Required(entry.slot)) throw new InvalidOperationException("필수 슬롯은 비울 수 없습니다: " + entry.slot);
                    selected.Remove(entry.slot);
                }
                else selected[entry.slot] = entry.Copy();
            }
            result.selections = new List<PartSelection>(selected.Values).ToArray();
            result.dependencyHash = null;
            return result;
        }

        public static List<string> Check(CharacterCatalog catalog, AppearanceRecipe recipe, bool release = false)
        {
            var errors = new List<string>();
            if (catalog == null || recipe == null) { errors.Add("카탈로그/프리셋 없음"); return errors; }
            if (recipe.schemaVersion != 1) errors.Add("지원하지 않는 스키마: " + recipe.schemaVersion);
            if (recipe.catalogVersion != catalog.version) errors.Add("카탈로그 버전 불일치");
            if (recipe.bodyId != catalog.bodyId) errors.Add("체형 불일치");
            if (string.IsNullOrWhiteSpace(recipe.recipeId) || recipe.revision < 1) errors.Add("프리셋 ID/리비전 오류");
            if (catalog.frameCount <= 0 || catalog.motion == null || catalog.motion.frames.Length != catalog.frameCount)
                errors.Add("모션 프레임 계약 불일치");
            if (catalog.pixelsPerUnit <= 0 || float.IsNaN(catalog.pixelsPerUnit) || float.IsInfinity(catalog.pixelsPerUnit))
                errors.Add("잘못된 PPU");
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var part in catalog.parts)
                if (part == null || string.IsNullOrWhiteSpace(part.id) || !ids.Add(part.id + "@" + part.revision))
                    errors.Add("중복 또는 잘못된 카탈로그 ID");
            var slots = new HashSet<AppearanceSlot>();
            foreach (var entry in recipe.selections ?? Array.Empty<PartSelection>())
            {
                if (entry == null) { errors.Add("빈 선택 항목"); continue; }
                if (!Enum.IsDefined(typeof(AppearanceSlot), entry.slot) || !slots.Add(entry.slot)) errors.Add("중복/잘못된 슬롯: " + entry.slot);
                if (entry.mode != SelectionMode.Select) errors.Add("미해결 선택: " + entry.slot);
                var part = catalog.Find(entry.partId, entry.revision);
                if (part == null) { errors.Add("파츠 없음: " + entry.partId); continue; }
                if (part.slot != entry.slot || part.bodyId != recipe.bodyId) errors.Add("파츠 호환 실패: " + part.id);
                if (part.slot == AppearanceSlot.Weapon && part.weaponFamily != recipe.weaponFamily) errors.Add("실제 무기 계열 불일치");
                if (catalog.Palette(entry.paletteId) == null || Array.IndexOf(part.paletteIds, entry.paletteId) < 0)
                    errors.Add("허용되지 않은 팔레트: " + part.id);
                if (part.pieces.Length == 0 && (!part.integratedBaseline || (part.slot != AppearanceSlot.Upper && part.slot != AppearanceSlot.Lower)))
                    errors.Add("렌더 조각 없음: " + part.id);
                var pieces = new HashSet<string>(StringComparer.Ordinal);
                foreach (var piece in part.pieces)
                {
                    if (piece == null || string.IsNullOrWhiteSpace(piece.id) || !pieces.Add(piece.id)) { errors.Add("중복/빈 렌더 조각: " + part.id); continue; }
                    if (piece.frames == null || piece.orders == null || piece.frames.Length != catalog.frameCount || piece.orders.Length != catalog.frameCount)
                    { errors.Add("포즈/레이어 누락: " + part.id + "/" + piece.id); continue; }
                    foreach (var sprite in piece.frames) if (sprite == null) { errors.Add("Sprite 누락: " + part.id + "/" + piece.id); break; }
                }
                foreach (string group in part.hideGroups)
                    if (!AllowedHide(part.slot, group)) errors.Add("금지된 가림: " + part.id + " → " + group);
            }
            foreach (AppearanceSlot slot in Enum.GetValues(typeof(AppearanceSlot)))
                if (Required(slot) && !slots.Contains(slot)) errors.Add("필수 슬롯 없음: " + slot);
            if (release)
            {
                if (catalog.trainingOnly) errors.Add("훈련 전용 카탈로그는 출하할 수 없습니다.");
                errors.AddRange(catalog.releaseBlockers);
            }
            if (!string.IsNullOrEmpty(recipe.dependencyHash) && recipe.dependencyHash != Fingerprint(catalog, recipe))
                errors.Add("발행 의존 해시 불일치");
            return errors;
        }

        private static bool AllowedHide(AppearanceSlot slot, string group) =>
            slot == AppearanceSlot.Head && (group == "hair_front" || group == "hair_back" || group == "beard") ||
            slot == AppearanceSlot.Upper && (group == "base_torso" || group == "base_arms") ||
            slot == AppearanceSlot.Lower && group == "base_legs";

        public static string Fingerprint(CharacterCatalog catalog, AppearanceRecipe recipe)
        {
            var copy = recipe.Copy(); copy.dependencyHash = null;
            Array.Sort(copy.selections, (a, b) => a.slot.CompareTo(b.slot));
            return Hash(catalog.sourceHash + "\n" + JsonUtility.ToJson(copy));
        }
        public static string Hash(string text)
        {
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-", "").ToLowerInvariant();
        }
    }
}
