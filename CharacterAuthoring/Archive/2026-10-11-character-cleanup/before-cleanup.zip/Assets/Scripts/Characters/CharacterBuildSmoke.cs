#if DEVELOPMENT_BUILD || UNITY_EDITOR
using System;
using System.Collections;
using System.IO;
using UnityEngine;

namespace Game.Characters
{
    /// <summary>Opt-in development-player smoke test. Does not run during normal play.</summary>
    public sealed class CharacterBuildSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void StartIfRequested()
        {
            if (Array.IndexOf(Environment.GetCommandLineArgs(), "-characterAssemblySmoke") < 0) return;
            new GameObject("Character build smoke").AddComponent<CharacterBuildSmoke>();
        }
        private IEnumerator Start()
        {
            float deadline = Time.realtimeSinceStartup + 10;
            CharacterAppearance actor = null;
            while (Time.realtimeSinceStartup < deadline)
            {
                actor = FindFirstObjectByType<CharacterAppearance>();
                if (actor != null && actor.IsReady) break;
                yield return null;
            }
            bool ok = actor != null && actor.IsReady;
            string result = "ready=" + ok + "\nleases=" + BuiltinVisualResourceProvider.Shared.ActiveLeases +
                "\ncatalog=" + (actor != null ? actor.Catalog.version : "missing") +
                "\nerror=" + (actor != null ? actor.LastError : "Actor missing");
            File.WriteAllText(Path.Combine(Application.dataPath, "../CharacterSmoke.txt"), result);
            Debug.Log("Character smoke: " + result);
            Application.Quit(ok ? 0 : 1);
        }
    }
}
#endif
