using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Game.Characters
{
    public interface IVisualResourceProvider
    {
        Task<VisualLease> AcquireAsync(CharacterCatalog catalog, PartSelection selection, CancellationToken cancellation);
    }

    public sealed class VisualLease : IDisposable
    {
        public VisualPart Part { get; }
        private Action release;
        public VisualLease(VisualPart part, Action release) { Part = part; this.release = release; }
        public void Dispose() => Interlocked.Exchange(ref release, null)?.Invoke();
    }

    /// <summary>Leases share catalog resources. Releasing a lease does not unload catalog-owned textures.</summary>
    public sealed class BuiltinVisualResourceProvider : IVisualResourceProvider
    {
        public static readonly BuiltinVisualResourceProvider Shared = new BuiltinVisualResourceProvider();
        private readonly Dictionary<string, int> references = new Dictionary<string, int>(StringComparer.Ordinal);
        private readonly object gate = new object();
        public int ActiveLeases { get { lock (gate) { int n = 0; foreach (var count in references.Values) n += count; return n; } } }
        public int CachedResources { get { lock (gate) return references.Count; } }

        public Task<VisualLease> AcquireAsync(CharacterCatalog catalog, PartSelection selection, CancellationToken cancellation)
        {
            cancellation.ThrowIfCancellationRequested();
            var part = catalog.Find(selection.partId, selection.revision);
            if (part == null) throw new InvalidOperationException("리소스 없음: " + selection.partId);
            string key = catalog.version + "/" + part.id + "@" + part.revision;
            lock (gate) references[key] = references.TryGetValue(key, out int count) ? count + 1 : 1;
            return Task.FromResult(new VisualLease(part, () =>
            {
                lock (gate)
                {
                    if (references[key] == 1) references.Remove(key);
                    else references[key]--;
                }
            }));
        }
    }
}
