using UnityEngine;
using UnityEngine.InputSystem;

namespace Game.Characters
{
    /// <summary>Isolated animation experiment; contains no combat or save calls.</summary>
    public sealed class CommonRigLabPlayback : MonoBehaviour
    {
        public CommonCharacterRig[] actors;
        public RigUpperMotion motion = RigUpperMotion.Slash;
        public int aimDirection = 3, moveDirection = 2;
        public bool walking = true, dashing, paused;
        private float time;
        public int Samples { get; private set; }
        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard != null)
            {
                if (keyboard.digit1Key.wasPressedThisFrame) motion = RigUpperMotion.Idle;
                if (keyboard.digit2Key.wasPressedThisFrame) motion = RigUpperMotion.Walk;
                if (keyboard.digit3Key.wasPressedThisFrame) motion = RigUpperMotion.Slash;
                if (keyboard.spaceKey.wasPressedThisFrame) paused = !paused;
                if (keyboard.upArrowKey.wasPressedThisFrame) aimDirection = 1;
                if (keyboard.downArrowKey.wasPressedThisFrame) aimDirection = 0;
                if (keyboard.leftArrowKey.wasPressedThisFrame) aimDirection = 2;
                if (keyboard.rightArrowKey.wasPressedThisFrame) aimDirection = 3;
                if (keyboard.wKey.wasPressedThisFrame) moveDirection = 1;
                if (keyboard.sKey.wasPressedThisFrame) moveDirection = 0;
                if (keyboard.aKey.wasPressedThisFrame) moveDirection = 2;
                if (keyboard.dKey.wasPressedThisFrame) moveDirection = 3;
                if (keyboard.tabKey.wasPressedThisFrame) walking = !walking;
                dashing = keyboard.leftShiftKey.isPressed;
            }
            if (!paused) time += Time.deltaTime;
            float duration = motion == RigUpperMotion.Slash ? .6f : .8f;
            foreach (var rig in actors)
                rig.Sample(motion, aimDirection, moveDirection, Mathf.Repeat(time, duration),
                    Mathf.Repeat(time, dashing ? .2f : .8f), walking, dashing);
            Samples++;
        }
    }
}
