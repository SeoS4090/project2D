using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace Game.Characters
{
    /// <summary>Presentation only. Prepared parts become visible together; combat owns animation timing.</summary>
    public sealed class CharacterAppearance : MonoBehaviour
    {
        [SerializeField] private CharacterCatalog catalog;
        [SerializeField] private AppearanceRecipe recipe;
        [SerializeField] private SpriteRenderer[] legacyRenderers = Array.Empty<SpriteRenderer>();
        [SerializeField] private Material spriteMaterial;
        private bool[] legacyEnabled;
        private CancellationTokenSource pending;
        private int generation, request;
        private Assembly active;
        private int upper, lower;
        public CharacterCatalog Catalog => catalog;
        public AppearanceRecipe AppliedRecipe { get; private set; }
        public string LastError { get; private set; }
        public bool IsReady => active != null;
        public IVisualResourceProvider Provider { get; set; }

        private sealed class Binding
        {
            public SpriteRenderer renderer;
            public VisualPiece piece;
        }
        private sealed class Assembly : IDisposable
        {
            public GameObject root;
            public readonly List<VisualLease> leases = new List<VisualLease>();
            public readonly List<Binding> bindings = new List<Binding>();
            public void Dispose()
            {
                if (root != null)
                {
                    root.SetActive(false);
                    if (Application.isPlaying) UnityEngine.Object.Destroy(root);
                    else UnityEngine.Object.DestroyImmediate(root);
                }
                foreach (var lease in leases) lease.Dispose();
                leases.Clear(); bindings.Clear();
            }
        }

        public void Configure(CharacterCatalog value, AppearanceRecipe initial, SpriteRenderer[] originals, Material material)
        {
            catalog = value; recipe = initial.Copy(); legacyRenderers = originals; spriteMaterial = material;
        }

        public void SetInitialRecipe(AppearanceRecipe value)
        {
            var errors = AppearanceValidation.Check(catalog, value);
            if (errors.Count > 0) throw new InvalidOperationException(string.Join("\n", errors));
            recipe = value.Copy();
        }

        private async void OnEnable()
        {
            generation++;
            if (catalog != null && recipe != null) await ApplyAsync(recipe);
        }

        public async Task<bool> ApplyAsync(AppearanceRecipe candidate)
        {
            int mine = ++request, life = generation;
            pending?.Cancel();
            var cancellation = new CancellationTokenSource();
            pending = cancellation;
            var staged = new Assembly();
            try
            {
                var snapshot = candidate?.Copy();
                var errors = AppearanceValidation.Check(catalog, snapshot);
                if (errors.Count != 0) throw new InvalidOperationException(string.Join("\n", errors));
                var provider = Provider ?? BuiltinVisualResourceProvider.Shared;
                var timeout = Task.Delay(TimeSpan.FromSeconds(10), cancellation.Token);
                foreach (var selected in snapshot.selections)
                {
                    var load = provider.AcquireAsync(catalog, selected, cancellation.Token);
                    if (await Task.WhenAny(load, timeout) != load)
                    {
                        cancellation.Cancel();
                        ReleaseWhenFinished(load);
                        throw new TimeoutException("외형 준비가 취소되었거나 10초를 초과했습니다.");
                    }
                    staged.leases.Add(await load);
                    cancellation.Token.ThrowIfCancellationRequested();
                }
                if (mine != request || life != generation || !isActiveAndEnabled) return false;
                staged.root = new GameObject("Character Visual (assembled)");
                staged.root.SetActive(false);
                staged.root.transform.SetParent(transform, false);
                var hidden = new HashSet<string>(StringComparer.Ordinal);
                foreach (var lease in staged.leases) foreach (var group in lease.Part.hideGroups) hidden.Add(group);
                for (int i = 0; i < staged.leases.Count; i++)
                {
                    var part = staged.leases[i].Part;
                    var palette = catalog.Palette(snapshot.selections[i].paletteId);
                    foreach (var piece in part.pieces)
                    {
                        if (!string.IsNullOrEmpty(piece.hideGroup) && hidden.Contains(piece.hideGroup)) continue;
                        var child = new GameObject(part.slot + "/" + piece.id);
                        child.transform.SetParent(staged.root.transform, false);
                        var renderer = child.AddComponent<SpriteRenderer>();
                        renderer.sharedMaterial = spriteMaterial;
                        if (legacyRenderers.Length > 0 && legacyRenderers[0] != null)
                            renderer.sortingLayerID = legacyRenderers[0].sortingLayerID;
                        renderer.color = piece.tintable ? palette.color : Color.white;
                        staged.bindings.Add(new Binding { renderer = renderer, piece = piece });
                    }
                }
                Render(staged, upper, lower);
                var previous = active;
                active = staged; staged = null;
                SuppressLegacy();
                active.root.SetActive(true);
                AppliedRecipe = snapshot;
                LastError = null;
                previous?.Dispose();
                return true;
            }
            catch (Exception exception)
            {
                if (mine == request && life == generation) LastError = exception.Message;
                return false;
            }
            finally
            {
                staged?.Dispose();
                cancellation.Cancel(); cancellation.Dispose();
                if (pending == cancellation) pending = null;
            }
        }

        // Also returns leases from providers that finish after cancellation; no Unity objects are touched.
        private static async void ReleaseWhenFinished(Task<VisualLease> task)
        {
            try { (await task)?.Dispose(); } catch { /* Load failure owns no lease. */ }
        }

        public bool RenderFrame(int upperFrame, int lowerFrame)
        {
            upper = upperFrame; lower = lowerFrame;
            if (active == null) return false;
            Render(active, upper, lower);
            return true;
        }

        private void Render(Assembly assembly, int upperFrame, int lowerFrame)
        {
            foreach (var binding in assembly.bindings)
            {
                int index = binding.piece.lowerBody ? lowerFrame : upperFrame;
                if (index < 0 || index >= catalog.frameCount) index = 0;
                binding.renderer.sprite = binding.piece.frames[index];
                binding.renderer.sortingOrder = binding.piece.orders[index];
            }
        }

        private void SuppressLegacy()
        {
            if (legacyEnabled != null) return;
            legacyEnabled = new bool[legacyRenderers.Length];
            for (int i = 0; i < legacyRenderers.Length; i++)
                if (legacyRenderers[i] != null) { legacyEnabled[i] = legacyRenderers[i].enabled; legacyRenderers[i].enabled = false; }
        }

        public void Release()
        {
            generation++; request++; pending?.Cancel();
            active?.Dispose(); active = null; AppliedRecipe = null;
            if (legacyEnabled != null)
                for (int i = 0; i < legacyRenderers.Length; i++)
                    if (legacyRenderers[i] != null) legacyRenderers[i].enabled = legacyEnabled[i];
            legacyEnabled = null; upper = lower = 0;
        }
        private void OnDisable() => Release();
        private void OnDestroy() => Release();
    }
}
