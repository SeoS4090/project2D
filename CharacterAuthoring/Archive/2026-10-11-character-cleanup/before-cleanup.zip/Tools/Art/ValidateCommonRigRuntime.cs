using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Game.Characters;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;

public static class ValidateCommonRigRuntime
{
    [Serializable] private sealed class Report { public List<string> passed = new List<string>(); public string failure; }
    public static async Task<string> Main()
    {
        var report = new Report();
        void Check(bool ok, string label) { if (!ok) throw new Exception(label); report.passed.Add(label); }
        var lab = UnityEngine.Object.FindFirstObjectByType<CommonRigLabPlayback>();
        if (lab == null || !Application.isPlaying) throw new Exception("Open CommonRigLab in Play mode");
        var oldBackground = InputSystem.settings.backgroundBehavior;
        var oldEditor = InputSystem.settings.editorInputBehaviorInPlayMode;
        var disabled = new List<InputDevice>();
        foreach (var device in InputSystem.devices) if (device is Keyboard && device.enabled) disabled.Add(device);
        foreach (var device in disabled) InputSystem.DisableDevice(device);
        InputSystem.settings.backgroundBehavior = InputSettings.BackgroundBehavior.IgnoreFocus;
        InputSystem.settings.editorInputBehaviorInPlayMode = InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
        var keyboard = InputSystem.AddDevice<Keyboard>();
        async Task Press(params Key[] keys)
        {
            InputSystem.QueueStateEvent(keyboard, new KeyboardState(keys)); await Task.Delay(100);
            InputSystem.QueueStateEvent(keyboard, new KeyboardState()); await Task.Delay(70);
        }
        try
        {
            int before = lab.Samples; await Task.Delay(150);
            Check(lab.Samples > before, "Actual Play Update samples the shared rig");
            Check(lab.actors.Length == 2 && lab.actors[0].Motions == lab.actors[1].Motions, "Two runtime actors share the same clips");
            await Press(Key.Digit2, Key.RightArrow, Key.D);
            Check(lab.motion == RigUpperMotion.Walk && lab.aimDirection == 3 && lab.moveDirection == 3, "Keyboard selects walk with matching aim/movement");
            await Press(Key.Digit3, Key.UpArrow, Key.A);
            Check(lab.motion == RigUpperMotion.Slash && lab.aimDirection == 1 && lab.moveDirection == 2, "Keyboard independently changes slash aim and movement");
            foreach (var actor in lab.actors) Check(actor.MainGripErrorPixels < 1 && actor.OffGripErrorPixels < 1, "Runtime grips stay connected: " + actor.Appearance.appearanceId);
            InputSystem.QueueStateEvent(keyboard, new KeyboardState(Key.LeftShift)); await Task.Delay(120);
            Check(lab.dashing && lab.motion == RigUpperMotion.Slash && lab.actors[0].OffGripErrorPixels < 1, "Held Shift combines lower dash with upper slash");
            InputSystem.QueueStateEvent(keyboard, new KeyboardState()); await Task.Delay(70);
            await Press(Key.Space);
            var weapon = lab.actors[0].transform.Find("Upper/Weapon");
            var rotation = weapon.localRotation; await Task.Delay(150);
            Check(lab.paused && Quaternion.Angle(rotation, weapon.localRotation) < .001f, "Pause holds the authored animation pose");
            await Press(Key.Space, Key.Digit1);
            Check(!lab.paused && lab.motion == RigUpperMotion.Idle, "Resume and idle selection work");
            Check(Camera.main.GetComponent<UnityEngine.Rendering.Universal.PixelPerfectCamera>().assetsPPU == 32, "URP pixel-perfect lab camera uses 32 PPU");
        }
        catch (Exception e) { report.failure = e.ToString(); }
        finally
        {
            InputSystem.RemoveDevice(keyboard); foreach (var device in disabled) InputSystem.EnableDevice(device);
            InputSystem.settings.backgroundBehavior = oldBackground; InputSystem.settings.editorInputBehaviorInPlayMode = oldEditor;
            lab.motion = RigUpperMotion.Slash; lab.aimDirection = 3; lab.moveDirection = 2; lab.paused = false; lab.dashing = false;
        }
        var json = JsonUtility.ToJson(report, true); Directory.CreateDirectory("Screenshots/CommonRigLab");
        File.WriteAllText("Screenshots/CommonRigLab/RuntimeValidation.json", json); return json;
    }
}
