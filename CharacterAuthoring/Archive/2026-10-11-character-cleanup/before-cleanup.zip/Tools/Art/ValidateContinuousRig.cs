using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Game.Characters;
using UnityEditor;
using UnityEngine;

public static class ValidateContinuousRig
{
    [Serializable] public class Report {
        public List<string> passed = new List<string>();
        public int samples;
        public float maximumGripErrorPixels, maximumReachCorrectionPixels, maximumBoundaryJumpPixels;
        public string failure = "";
    }
    static Vector2 Aim(float angle) => new Vector2(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad));
    public static string Main()
    {
        var report = new Report(); var preview = new PreviewRenderUtility(); var rigs = new List<CommonCharacterRig>();
        void Check(bool ok, string name) { if (!ok) throw new Exception(name); report.passed.Add(name); }
        Directory.CreateDirectory("Screenshots/CommonRigLab/ContinuousFrames");
        try
        {
            foreach (var id in new[] { "blue-tunic", "bronze-armor" })
            {
                var go = UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(CommonRigLabBuilder.Root + id + ".prefab"));
                preview.AddSingleGO(go); go.transform.position = new Vector3(rigs.Count == 0 ? -1.5f : 1.5f, 0, 0);
                rigs.Add(go.GetComponent<CommonCharacterRig>());
            }
            var motions = (RigUpperMotion[])Enum.GetValues(typeof(RigUpperMotion));
            foreach (var motion in motions)
            {
                Check(AnimationUtility.GetObjectReferenceCurveBindings(rigs[0].Motions.Upper(motion, 3)).Length == 0, motion + " shares Transform-only canonical clip");
                for (int degree = 0; degree < 360; degree += 2)
                for (int frame = 0; frame <= 40; frame++)
                foreach (var rig in rigs)
                {
                    rig.SampleContinuous(motion, Aim(degree), frame % 4, frame / 40f * rig.Motions.Upper(motion, 3).length, frame / 50f, true, frame % 5 == 0);
                    report.maximumGripErrorPixels = Mathf.Max(report.maximumGripErrorPixels, rig.MainGripErrorPixels, rig.OffGripErrorPixels);
                    report.maximumReachCorrectionPixels = Mathf.Max(report.maximumReachCorrectionPixels, rig.ReachCorrectionPixels);
                    CheckFinite(rig.transform.Find("Upper/MainArm").localRotation);
                    if (Vector3.Distance(rig.transform.Find("Upper/MainArm").localPosition, new Vector3(4,17,0)/32) > .00001f)
                        throw new Exception("Shoulder detached from fixed sleeve socket");
                    report.samples++;
                }
            }
            Check(report.maximumGripErrorPixels < .01f, "All angles, seven motions, two appearances: both grips within 0.01 source px");
            Check(report.maximumReachCorrectionPixels < .01f, "Authored paths fit fixed-length arms without reach clamping");
            var first = rigs[0];
            foreach (float boundary in new[] {45f,135f,225f,315f,360f})
            foreach (var motion in motions)
            for (int f = 0; f <= 20; f++)
            {
                float t = f / 20f * first.Motions.Upper(motion, 3).length;
                first.SampleContinuous(motion, Aim(boundary-.001f), 0, t, .2f, true);
                var before = first.transform.Find("Upper/Weapon").position;
                first.SampleContinuous(motion, Aim(boundary+.001f), 0, t, .2f, true);
                report.maximumBoundaryJumpPixels = Mathf.Max(report.maximumBoundaryJumpPixels, Vector3.Distance(before, first.transform.Find("Upper/Weapon").position)*32);
            }
            Check(report.maximumBoundaryJumpPixels < .002f, "No weapon-path discontinuity across cardinal sprite boundaries or 360 wrap");
            first.SampleContinuous(RigUpperMotion.Slash, Aim(28), 0, .21f, .2f, true);
            var weapon = first.transform.Find("Upper/Weapon").position;
            first.SampleContinuous(RigUpperMotion.Slash, Aim(28), 2, .21f, .53f, true, true);
            Check(Vector3.Distance(weapon, first.transform.Find("Upper/Weapon").position) < .00001f, "Dash and lower-body direction do not change upper aim pose");
            int assignments = first.SpriteAssignments;
            for (int i=0;i<100;i++) first.SampleContinuous(RigUpperMotion.Walk, Aim(10+i*.2f), 2, i*.01f, i*.01f, true);
            Check(assignments == first.SpriteAssignments, "Continuous aim within a view sector does not reassign Sprites");
            first.SampleContinuous(RigUpperMotion.Spin, Vector2.right, 0, .32f*.6f, 0, false);
            int behind = first.transform.Find("Upper/Weapon/Blade").GetComponent<SpriteRenderer>().sortingOrder;
            first.SampleContinuous(RigUpperMotion.Spin, Vector2.right, 0, .65f*.6f, 0, false);
            Check(behind < 4 && first.transform.Find("Upper/Weapon/Blade").GetComponent<SpriteRenderer>().sortingOrder > 8,
                "Spin changes weapon occlusion with its orbit while body facing stays fixed");
            var second = rigs[1];
            foreach(var motion in motions)
            {
                first.SampleContinuous(motion, Aim(123), 3,.23f,.1f,true);
                second.SampleContinuous(motion,Aim(123),3,.23f,.1f,true);
                Check(Quaternion.Angle(first.transform.Find("Upper/Weapon").rotation,second.transform.Find("Upper/Weapon").rotation)<.001f, motion+" pose shared across appearances");
            }
            Capture(preview, rigs);
        }
        catch(Exception e) { report.failure = e.ToString(); }
        finally { preview.Cleanup(); }
        string json = JsonUtility.ToJson(report,true); File.WriteAllText("Screenshots/CommonRigLab/ContinuousValidation.json",json); return json;
    }
    static void CheckFinite(Quaternion q) { if(float.IsNaN(q.x)||float.IsNaN(q.y)||float.IsNaN(q.z)||float.IsNaN(q.w))throw new Exception("Nonfinite arm pose"); }
    static void Capture(PreviewRenderUtility preview,List<CommonCharacterRig> rigs)
    {
        var camera=preview.camera;camera.orthographic=true;camera.orthographicSize=2.5f;camera.transform.position=new Vector3(0,1,-10);
        camera.nearClipPlane=.1f;camera.farClipPlane=30;camera.allowHDR=camera.allowMSAA=false;
        camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.078f,.125f,.16f);
        var cell=new Texture2D(320,160,TextureFormat.RGB24,false);
        var grid=new Texture2D(320*8,160*3,TextureFormat.RGB24,false);
        try {
            for(int row=0;row<3;row++)for(int col=0;col<8;col++) {
                foreach(var rig in rigs)rig.SampleContinuous(row==0?RigUpperMotion.Walk:row==1?RigUpperMotion.Slash:RigUpperMotion.Spin,Aim(col*45),2,row==0?.2f:row==1?.29f:.37f,.2f,true);
                Render(preview,cell);grid.SetPixels(col*320,(2-row)*160,320,160,cell.GetPixels());
            }
            grid.Apply();File.WriteAllBytes("Screenshots/CommonRigLab/ContinuousComparison.png",grid.EncodeToPNG());
            for(int f=0;f<72;f++) {
                foreach(var rig in rigs)rig.SampleContinuous(RigUpperMotion.Walk,Aim(f*5),2,f/60f,f/60f,true);
                Render(preview,cell);File.WriteAllBytes("Screenshots/CommonRigLab/ContinuousFrames/"+f.ToString("D3")+".png",cell.EncodeToPNG());
            }
        } finally {UnityEngine.Object.DestroyImmediate(cell);UnityEngine.Object.DestroyImmediate(grid);}
    }
    static void Render(PreviewRenderUtility preview,Texture2D output) {
        preview.BeginPreview(new Rect(0,0,320,160),GUIStyle.none);preview.camera.Render();var texture=preview.EndPreview();var prior=RenderTexture.active;
        RenderTexture.active=(RenderTexture)texture;output.ReadPixels(new Rect(0,0,320,160),0,0);output.Apply();RenderTexture.active=prior;
    }
}
