using System;
using System.Collections.Generic;
using System.IO;
using Game.Characters;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public static class ValidateRigAdapter
{
    [Serializable] public class Report { public List<string> passed = new List<string>(); public string failure = ""; }
    public static string Main()
    {
        var report = new Report(); var preview = new PreviewRenderUtility(); var root = new GameObject("Adapter test");preview.AddSingleGO(root);
        void Check(bool ok,string label) { if(!ok)throw new Exception(label);report.passed.Add(label); }
        try {
            var go=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(CommonRigLabBuilder.Root+"blue-tunic.prefab"),root.transform);
            var rig=go.GetComponent<CommonCharacterRig>();var view=root.AddComponent<TrainingPlayerView>();view.BindCommonRig(rig);
            Vector2 aim=new Vector2(.8f,.6f),other=Vector2.left;
            view.SetState(Vector2.down,aim,false,true,aim,1,.12f,.08f,.12f);
            Check(Mathf.Abs(view.RigPhase-.32f)<.00001f,"Active begins at authored windup boundary");
            view.SetState(Vector2.down,other,false,true,aim,1,0,.08f,.12f);
            Check(Mathf.Abs(view.RigPhase-.70f)<.00001f && Mathf.Abs(rig.AimAngle-36.8699f)<.001f,"Active ends at recovery boundary and retains non-cardinal execution aim");
            var last=rig.transform.Find("Upper/Weapon").position;
            view.SetState(Vector2.down,other,false,false,aim,1,0,.08f,.12f,recovering:true,recoveryProgress:0);
            Check(Vector3.Distance(last,rig.transform.Find("Upper/Weapon").position)<.000001f,"Active-to-recovery pose is continuous");
            view.SetState(Vector2.down,other,false,true,aim,1,0,0,0);
            Check(view.RigPhase==.70f && !float.IsNaN(rig.AimAngle),"Zero duration active phase reaches endpoint safely");
            view.SetState(Vector2.right,aim,false,false,aim,1,0,.08f,.12f);
            view.SetState(Vector2.right,Vector2.zero,false,false,aim,1,0,.08f,.12f);
            Check(Mathf.Abs(rig.AimAngle-36.8699f)<.001f,"Zero mouse vector retains previous valid aim");
            rig.gameObject.SetActive(false);rig.gameObject.SetActive(true);
            view.SetState(Vector2.right,aim,false,false,aim,1,0,.08f,.12f,dashing:true,dashDirection:Vector2.up,dashProgress:.5f,charging:true,chargeElapsed:.2f);
            Check(rig.MainGripErrorPixels<.01f&&rig.OffGripErrorPixels<.01f,"Re-enabled rig rebuilds graph and supports charge plus dash");
            var before=rig.Motions;rig.SetAppearance(AssetDatabase.LoadAssetAtPath<CommonRigAppearance>(CommonRigLabBuilder.Root+"bronze-armor.asset"));
            view.SetState(Vector2.zero,aim,false,true,aim,2,.06f,.08f,.12f,attackClip:"attack_reverse");
            Check(rig.Motions==before&&view.CurrentMotion=="attack_reverse / active"&&rig.OffGripErrorPixels<.01f,"Appearance swap preserves shared reverse motion in adapter");
            var window=EditorWindow.GetWindow<CommonRigLabWindow>();window.position=new Rect(40,60,1100,800);window.Focus();
            var tree=window.rootVisualElement;
            Check(tree.Q<Slider>("angle")!=null && tree.Q<Toggle>("continuous").value && tree.Q<DropdownField>("motion").choices.Count==7,"Comparison UI imports continuous angle control and seven motions");
            tree.Q<DropdownField>("motion").index=6;tree.Q<Slider>("angle").value=137;
            typeof(CommonRigLabWindow).GetMethod("Tick",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance).Invoke(window,null);
            Check(tree.Q<Label>("diagnostics").text.Contains("0.000px"),"Comparison controls execute a continuous spin preview");
        }catch(Exception e){report.failure=e.ToString();}finally{preview.Cleanup();}
        string json=JsonUtility.ToJson(report,true);File.WriteAllText("Screenshots/CommonRigLab/AdapterValidation.json",json);return json;
    }
}
