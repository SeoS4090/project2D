using System;
using System.Collections.Generic;
using System.IO;
using Game.Characters;
using UnityEditor;
using UnityEngine;

public static class ValidateCharacterAuthoring
{
    [Serializable] private sealed class Report { public List<string> passed = new List<string>(); public string failure; }
    public static string Main()
    {
        var report = new Report();
        void Check(bool valid, string label) { if (!valid) throw new Exception(label); report.passed.Add(label); }
        bool Reject(Action action) { try { action(); return false; } catch (InvalidOperationException) { return true; } catch (InvalidDataException) { return true; } }
        string id = "validation-" + Guid.NewGuid().ToString("N");
        string path = CharacterContentBuilder.DraftRoot + id + ".json";
        string published = CharacterContentBuilder.PublishedRoot + "Training/" + id;
        var catalog = AssetDatabase.LoadAssetAtPath<CharacterCatalog>(CharacterContentBuilder.CatalogPath);
        try
        {
            var draft = new AppearanceDraft { draftId = id, baseline = catalog.baseline.Copy() };
            CharacterContentBuilder.SaveDraft(draft);
            Check(draft.revision == 1 && File.Exists(path), "Draft saved and read back at revision 1");
            var stale = JsonUtility.FromJson<AppearanceDraft>(File.ReadAllText(path));
            CharacterContentBuilder.SaveDraft(draft);
            Check(draft.revision == 2 && File.Exists(path + ".bak"), "Atomic update preserves previous draft backup");
            Check(Reject(() => CharacterContentBuilder.SaveDraft(stale)), "Stale draft cannot overwrite newer revision");
            Check(JsonUtility.FromJson<AppearanceDraft>(File.ReadAllText(path)).revision == 2, "Conflict leaves current draft intact");
            Check(Reject(() => CharacterContentBuilder.SafeName("../escape")), "Draft path traversal rejected");
            var recipe = catalog.baseline.Copy(); recipe.recipeId = id; recipe.dependencyHash = null;
            string reviewed = AppearanceValidation.Fingerprint(catalog, recipe);
            Check(Reject(() => CharacterContentBuilder.Publish(catalog, recipe, "old-hash", false)), "Changed preview requires new review");
            string snapshot = CharacterContentBuilder.Publish(catalog, recipe, reviewed, false);
            Check(File.Exists(snapshot) && File.Exists(published + "/current.json"), "Training snapshot and current pointer published");
            string original = File.ReadAllText(snapshot);
            Check(Reject(() => CharacterContentBuilder.Publish(catalog, recipe, reviewed, false)), "Published revision is immutable");
            Check(File.ReadAllText(snapshot) == original, "Rejected republish preserves published bytes");
            recipe.revision = 2;
            Check(Reject(() => CharacterContentBuilder.Publish(catalog, recipe, reviewed, false)), "Revision change invalidates approval hash");
            CharacterContentBuilder.Publish(catalog, recipe, AppearanceValidation.Fingerprint(catalog, recipe), false);
            Check(JsonUtility.FromJson<AppearanceRecipe>(File.ReadAllText(published + "/current.json")).revision == 2 && File.Exists(published + "/current.json.bak"),
                "New revision atomically updates current pointer and preserves backup");
            Check(Reject(() => CharacterContentBuilder.Publish(catalog, recipe, AppearanceValidation.Fingerprint(catalog, recipe), true)),
                "Training catalog cannot be published for release");
            var future = catalog.baseline.Copy(); future.schemaVersion = 999;
            Check(AppearanceValidation.Check(catalog, future).Count > 0, "Future schema rejected without saving");
        }
        catch (Exception e) { report.failure = e.ToString(); }
        finally
        {
            // Only files under this freshly generated test ID belong to this fixture.
            foreach (var file in new[] { path, path + ".bak", published + "/1.json", published + "/2.json", published + "/current.json", published + "/current.json.bak" })
                if (File.Exists(file)) File.Delete(file);
            if (Directory.Exists(published) && Directory.GetFileSystemEntries(published).Length == 0) Directory.Delete(published);
        }
        string json = JsonUtility.ToJson(report, true);
        Directory.CreateDirectory("Screenshots/CharacterAssembly");
        File.WriteAllText("Screenshots/CharacterAssembly/AuthoringValidation.json", json);
        return json;
    }
}
