-- Static cutout parts for a shared Transform rig; rows are body parts, not animation frames.
local root='Assets/Art/Characters/CommonRigLab/'
app.fs.makeAllDirectories(root)
local original=app.open('Assets/Art/Characters/MannequinMotion/MannequinMotion.aseprite')
local headLayer
for _,layer in ipairs(original.layers) do if layer.name=='Head' then headLayer=layer end end
assert(headLayer,'Missing authored head layer')
local names={'head','torso','upperArm','forearm','hand','leg','weapon','shadow'}
local function c(hex) return Color{r=tonumber(hex:sub(1,2),16),g=tonumber(hex:sub(3,4),16),b=tonumber(hex:sub(5,6),16),a=255} end
local ink=c('25343e'); local skin=c('c4cfcb'); local edge=c('eef4ec')
local function rect(im,x,y,w,h,col) for yy=y,y+h-1 do for xx=x,x+w-1 do im:drawPixel(xx,yy,col) end end end
local function ellipse(im,x,y,rx,ry,col)
 for yy=y-ry,y+ry do for xx=x-rx,x+rx do if ((xx-x)/rx)^2+((yy-y)/ry)^2<=1 then im:drawPixel(xx,yy,col) end end end
end
for appearance=1,2 do
 local base=appearance==1 and c('397fa4') or c('b48648')
 local light=appearance==1 and c('73bed0') or c('e3c58a')
 local pants=appearance==1 and c('394e63') or c('624b43')
 local sheet=Image(256,#names*64,ColorMode.RGB)
 local source=Sprite(64,64,ColorMode.RGB)
 for row,name in ipairs(names) do
  local layer=row==1 and source.layers[1] or source:newLayer(); layer.name=name
  for dir=0,3 do
   if #source.frames<dir+1 then source:newEmptyFrame() end
   local im=Image(64,64,ColorMode.RGB)
   if name=='head' then
    local cel=headLayer:cel(dir*108+1)
    im:drawImage(cel.image,Point(cel.position.x-32,cel.position.y-40))
   elseif name=='torso' then
    local w=dir>=2 and 9 or 13
    rect(im,32-math.floor(w/2)-1,25,w+2,15,ink)
    rect(im,32-math.floor(w/2),26,w,12,base)
    if appearance==1 then
     rect(im,32-math.floor(w/2),36,w,2,pants)
     if dir~=1 then rect(im,31,26,2,9,light) end
    else
     rect(im,32-math.floor(w/2),26,w,3,light)
     rect(im,32-math.floor(w/2),31,w,1,ink)
     rect(im,32-math.floor(w/2),35,w,1,ink)
    end
   elseif name=='upperArm' or name=='forearm' then
    local width=name=='upperArm' and (appearance==2 and 9 or 7) or 5
    rect(im,31,32-math.floor(width/2),11,width,ink)
    rect(im,32,33-math.floor(width/2),9,width-2,base)
    rect(im,33,33-math.floor(width/2),7,1,light)
    if appearance==2 then rect(im,36,32-math.floor(width/2),1,width,ink) end
   elseif name=='hand' then
    ellipse(im,32,32,3,3,ink); ellipse(im,32,32,2,2,skin)
   elseif name=='leg' then
    rect(im,29,31,7,10,ink); rect(im,30,32,5,6,pants)
    rect(im,29,38,appearance==2 and 9 or 8,3,ink)
    rect(im,30,38,5,1,light)
   elseif name=='weapon' then
    rect(im,25,30,16,5,ink); rect(im,26,31,13,3,pants)
    rect(im,37,25,3,15,ink); rect(im,38,26,1,13,light)
    local bladeWidth=appearance==1 and 3 or 5
    for x=40,61 do
     local half=math.min(bladeWidth,math.floor((62-x)/2))
     rect(im,x,32-half,1,half*2+1,ink)
     if half>0 then rect(im,x,33-half,1,half*2-1,light) end
     if half>1 then im:drawPixel(x,31,edge) end
    end
   elseif name=='shadow' then ellipse(im,32,32,16,2,c('344651')) end
   source:newCel(layer,dir+1,im,Point(0,0))
   sheet:drawImage(im,Point(dir*64,(row-1)*64))
  end
 end
 local id=appearance==1 and 'blue-tunic' or 'bronze-armor'
 source:saveAs(root..id..'.aseprite'); source:close(); sheet:saveAs(root..id..'.png')
end
original:close()
print('Two appearance sets: 8 static part types x 4 views. No animation-frame images.')
