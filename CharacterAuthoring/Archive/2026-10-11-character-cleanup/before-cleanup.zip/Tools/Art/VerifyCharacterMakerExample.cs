using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public static class VerifyCharacterMakerExample
{
    public static async Task<string> Main()
    {
        CharacterMakerWindow.Open();
        var window = EditorWindow.GetWindow<CharacterMakerWindow>();
        window.position = new Rect(40, 60, 1100, 860); window.Focus();
        await Task.Delay(500);
        var root = window.rootVisualElement;
        var palettes = root.Query<DropdownField>().ToList().Where(f => f.label == "팔레트").ToArray();
        if (palettes.Length != 4) throw new Exception("Expected four occupied slots");
        palettes[1].value = "cool"; palettes[2].value = "warm";
        root.Q<Toggle>("playing").value = false;
        root.Q<DropdownField>("direction").index = 3;
        root.Q<Slider>("time").value = .1f;
        root.Q<TextField>("draftId").value = "training-two-tone";
        root.Q<TextField>("recipeId").value = "recipe.training.two-tone";
        await Task.Delay(300);
        void Click(string name)
        {
            using (var evt = NavigationSubmitEvent.GetPooled()) root.Q<Button>(name).SendEvent(evt);
        }
        Click("validate");
        if (!root.Q<Label>("diagnostics").text.Contains("통과")) throw new Exception(root.Q<Label>("diagnostics").text);
        if (!File.Exists("CharacterAuthoring/Drafts/training-two-tone.json")) { Click("newDraft"); Click("save"); }
        if (!File.Exists("CharacterAuthoring/Published/Training/recipe.training.two-tone/1.json")) Click("publish");
        if (!File.Exists("CharacterAuthoring/Published/Training/recipe.training.two-tone/1.json"))
            throw new Exception(root.Q<Label>("diagnostics").text);
        await Task.Delay(300);
        var position = window.position;
        var texture = new Texture2D((int)position.width, (int)position.height, TextureFormat.RGB24, false);
        texture.SetPixels(UnityEditorInternal.InternalEditorUtility.ReadScreenPixel(position.position, texture.width, texture.height));
        texture.Apply();
        Directory.CreateDirectory("Screenshots/CharacterAssembly");
        File.WriteAllBytes("Screenshots/CharacterAssembly/Maker.png", texture.EncodeToPNG());
        UnityEngine.Object.DestroyImmediate(texture);
        return root.Q<Label>("diagnostics").text;
    }
}
