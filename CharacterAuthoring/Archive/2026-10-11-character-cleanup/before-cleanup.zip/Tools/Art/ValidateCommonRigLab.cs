using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Game.Characters;
using UnityEditor;
using UnityEngine;

public static class ValidateCommonRigLab
{
    [Serializable] public sealed class Report
    {
        public List<string> passed = new List<string>();
        public float maximumMainGripErrorPixels, maximumOffGripErrorPixels, maximumAppearancePoseDifference;
        public int samples, clips, staticSprites;
        public string failure;
    }
    public static string Main()
    {
        var report = new Report();
        void Check(bool ok, string name) { if (!ok) throw new Exception(name); report.passed.Add(name); }
        var preview = new PreviewRenderUtility();
        var rigs = new List<CommonCharacterRig>();
        Directory.CreateDirectory("Screenshots/CommonRigLab");
        try
        {
            foreach (string id in new[] { "blue-tunic", "bronze-armor" })
            {
                var go = UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(CommonRigLabBuilder.Root + id + ".prefab"));
                preview.AddSingleGO(go); go.transform.position = new Vector3(rigs.Count == 0 ? -1.5f : 1.5f, 0, 0);
                rigs.Add(go.GetComponent<CommonCharacterRig>());
            }
            var motions = rigs[0].Motions;
            Check(motions == rigs[1].Motions, "Both appearances reference the same motion asset");
            Check(rigs[0].Appearance != rigs[1].Appearance, "Two different appearance assets");
            Check(rigs[0].Appearance.torso[0] != rigs[1].Appearance.torso[0] && rigs[0].Appearance.weapon[0] != rigs[1].Appearance.weapon[0], "Distinct clothing and blade art, not only renderer tint");
            var clips = motions.idle.Concat(motions.walk).Concat(motions.slash).Concat(motions.lowerIdle).Concat(motions.lowerWalk).Concat(motions.lowerDash).ToArray();
            report.clips = clips.Length;
            Check(clips.All(c => AnimationUtility.GetObjectReferenceCurveBindings(c).Length == 0), "All clips contain zero Sprite/object-reference curves");
            Check(clips.All(c => AnimationUtility.GetCurveBindings(c).All(b => b.type == typeof(Transform))), "All animation bindings target Transform properties");
            report.staticSprites = 2 * 8 * 4;
            foreach (var motion in new[] { RigUpperMotion.Idle, RigUpperMotion.Walk, RigUpperMotion.Slash })
            for (int aim = 0; aim < 4; aim++) for (int move = 0; move < 4; move++)
            for (int i = 0; i <= 257; i++)
            {
                float phase = i / 257f;
                foreach (var rig in rigs)
                {
                    rig.Sample(motion, aim, move, phase * (motion == RigUpperMotion.Slash ? .6f : .8f), phase * .8f, true);
                    report.maximumMainGripErrorPixels = Mathf.Max(report.maximumMainGripErrorPixels, rig.MainGripErrorPixels);
                    report.maximumOffGripErrorPixels = Mathf.Max(report.maximumOffGripErrorPixels, rig.OffGripErrorPixels);
                    report.samples++;
                }
                foreach (string path in CommonRigLabBuilder.Paths.Where(p => p.Length > 0))
                {
                    var a = rigs[0].transform.Find(path); var b = rigs[1].transform.Find(path);
                    report.maximumAppearancePoseDifference = Mathf.Max(report.maximumAppearancePoseDifference,
                        Vector3.Distance(a.localPosition, b.localPosition) * 32, Quaternion.Angle(a.localRotation, b.localRotation));
                }
            }
            Check(report.maximumMainGripErrorPixels < 1, "Main hand connects to grip within one source pixel across all sampled views/motions");
            Check(report.maximumOffGripErrorPixels < 1, "Off hand connects to grip within one source pixel across all sampled views/motions");
            Check(report.maximumAppearancePoseDifference < .001f, "Both outfits produce identical joint transforms for identical animation input");
            var first = rigs[0];
            first.Sample(RigUpperMotion.Slash, 3, 2, .23f, .2f, true);
            Vector3 head = first.transform.Find("Upper/Head").position;
            Quaternion blade = first.transform.Find("Upper/Weapon").rotation;
            first.Sample(RigUpperMotion.Slash, 3, 0, .23f, .4f, true);
            Check(Vector3.Distance(head, first.transform.Find("Upper/Head").position) < .0001f && Quaternion.Angle(blade, first.transform.Find("Upper/Weapon").rotation) < .001f,
                "Changing lower movement direction/phase leaves attacking upper body unchanged");
            first.Sample(RigUpperMotion.Idle, 3, 2, .1f, .3f, true);
            var leg = first.transform.Find("Lower/LeftLeg").localRotation;
            first.Sample(RigUpperMotion.Slash, 1, 2, .4f, .3f, true);
            Check(Quaternion.Angle(leg, first.transform.Find("Lower/LeftLeg").localRotation) < .001f, "Changing upper motion/aim leaves lower walk pose unchanged");
            int assignments = first.SpriteAssignments;
            for (int i = 0; i < 300; i++) first.Sample(RigUpperMotion.Slash, 1, 2, i / 500f, i / 500f, true);
            Check(first.SpriteAssignments == assignments, "300 animation updates perform zero Sprite assignments at fixed view");
            first.Sample(RigUpperMotion.Slash, 0, 3, .27f, .1f, true, true);
            Check(first.MainGripErrorPixels < 1 && first.OffGripErrorPixels < 1, "Dash lower layer preserves slash grips");
            first.SetAppearance(rigs[1].Appearance);
            first.Sample(RigUpperMotion.Slash, 0, 3, .27f, .1f, true, true);
            Check(first.Motions == motions && first.MainGripErrorPixels < 1, "Appearance replacement reuses motion asset and grip geometry");
            first.SetAppearance(AssetDatabase.LoadAssetAtPath<CommonRigAppearance>(CommonRigLabBuilder.Root + "blue-tunic.asset"));
            first.Sample(RigUpperMotion.Walk, 3, 2, .123f, .29f, true, false, true);
            Check(first.MainGripErrorPixels < 1 && first.OffGripErrorPixels < 1, "Integer root snapping preserves both grip connections");
            Capture(preview, rigs);
            Check(File.Exists("Screenshots/CommonRigLab/Comparison.png"), "Four-direction slash comparison rendered");
        }
        catch (Exception e) { report.failure = e.ToString(); }
        finally { preview.Cleanup(); }
        string json = JsonUtility.ToJson(report, true);
        File.WriteAllText("Screenshots/CommonRigLab/Validation.json", json);
        return json;
    }

    private static void Capture(PreviewRenderUtility preview, List<CommonCharacterRig> rigs)
    {
        var camera = preview.camera;
        camera.orthographic = true; camera.orthographicSize = 2.5f; camera.transform.position = new Vector3(0, 1, -10);
        camera.nearClipPlane = .1f; camera.farClipPlane = 30; camera.allowHDR = camera.allowMSAA = false;
        camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.078f, .125f, .16f);
        var overview = new Texture2D(320 * 5, 160 * 4, TextureFormat.RGB24, false);
        var cell = new Texture2D(320, 160, TextureFormat.RGB24, false);
        try
        {
            for (int direction = 0; direction < 4; direction++) for (int pose = 0; pose < 5; pose++)
            {
                foreach (var rig in rigs) rig.Sample(RigUpperMotion.Slash, direction, direction ^ 1, pose * .15f, pose * .2f, true);
                Render(preview, cell);
                overview.SetPixels(pose * 320, (3 - direction) * 160, 320, 160, cell.GetPixels());
            }
            overview.Apply(); File.WriteAllBytes("Screenshots/CommonRigLab/Comparison.png", overview.EncodeToPNG());
            Directory.CreateDirectory("Screenshots/CommonRigLab/Frames");
            for (int frame = 0; frame < 48; frame++)
            {
                foreach (var rig in rigs) rig.Sample(RigUpperMotion.Slash, 3, 2, frame / 80f, frame / 60f, true);
                Render(preview, cell);
                File.WriteAllBytes("Screenshots/CommonRigLab/Frames/" + frame.ToString("D3") + ".png", cell.EncodeToPNG());
            }
            Directory.CreateDirectory("Screenshots/CommonRigLab/WalkFrames");
            for (int frame = 0; frame < 48; frame++)
            {
                foreach (var rig in rigs) rig.Sample(RigUpperMotion.Walk, 3, 3, frame / 60f, frame / 60f, true);
                Render(preview, cell);
                File.WriteAllBytes("Screenshots/CommonRigLab/WalkFrames/" + frame.ToString("D3") + ".png", cell.EncodeToPNG());
            }
        }
        finally { UnityEngine.Object.DestroyImmediate(cell); UnityEngine.Object.DestroyImmediate(overview); }
    }
    private static void Render(PreviewRenderUtility preview, Texture2D output)
    {
        preview.BeginPreview(new Rect(0, 0, 320, 160), GUIStyle.none); preview.camera.Render();
        var result = preview.EndPreview(); var previous = RenderTexture.active;
        RenderTexture.active = (RenderTexture)result;
        output.ReadPixels(new Rect(0, 0, 320, 160), 0, 0); output.Apply();
        RenderTexture.active = previous;
    }
}
