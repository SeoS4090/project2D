using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BuildCharacterAssembly
{
    public static string Main()
    {
        Directory.CreateDirectory("Temp/CharacterAssemblyBuild");
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
        {
            scenes = new[] { "Assets/Scenes/TrainingGround.unity" },
            locationPathName = "Temp/CharacterAssemblyBuild/Training.exe",
            target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.Development
        });
        string text = "result=" + report.summary.result + "\nerrors=" + report.summary.totalErrors +
            "\nwarnings=" + report.summary.totalWarnings + "\nbytes=" + report.summary.totalSize +
            "\nduration=" + report.summary.totalTime;
        Directory.CreateDirectory("Screenshots/CharacterAssembly");
        File.WriteAllText("Screenshots/CharacterAssembly/PlayerBuild.txt", text);
        return text;
    }
}
