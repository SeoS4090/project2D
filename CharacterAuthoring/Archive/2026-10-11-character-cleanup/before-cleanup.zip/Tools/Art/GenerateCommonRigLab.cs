public static class GenerateCommonRigLab
{
    public static string Main()
    {
        CommonRigLabBuilder.Generate();
        CommonRigLabWindow.Open();
        return "Shared Transform clips, two cutout appearances and comparison window generated.";
    }
}
