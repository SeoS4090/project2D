using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Game.Characters;
using UnityEditor;
using UnityEngine;

public static class ValidateCharacterAssembly
{
    [Serializable] public sealed class Report
    {
        public string catalog;
        public List<string> passed = new List<string>();
        public string failure;
        public int referenceBaseline, referenceAfter;
        public long renderAllocatedBytes;
    }
    private sealed class DelayedProvider : IVisualResourceProvider
    {
        public readonly TaskCompletionSource<VisualLease> completion = new TaskCompletionSource<VisualLease>();
        public Task<VisualLease> AcquireAsync(CharacterCatalog c, PartSelection p, CancellationToken t) => completion.Task;
    }
    public static async Task<string> Main()
    {
        var report = new Report();
        void Check(bool ok, string label) { if (!ok) throw new Exception(label); report.passed.Add(label); }
        var catalog = AssetDatabase.LoadAssetAtPath<CharacterCatalog>(CharacterContentBuilder.CatalogPath);
        var provider = BuiltinVisualResourceProvider.Shared;
        report.catalog = catalog.version; report.referenceBaseline = provider.ActiveLeases;
        var root = new GameObject("Assembly verification");
        var material = new Material(Shader.Find("Sprites/Default"));
        var actor = root.AddComponent<CharacterAppearance>();
        actor.Configure(catalog, catalog.baseline, Array.Empty<SpriteRenderer>(), material);
        CharacterCatalog damaged = null;
        try
        {
            Check(AppearanceValidation.Check(catalog, catalog.baseline).Count == 0, "Imported baseline validates");
            Check(AppearanceValidation.Check(catalog, catalog.baseline, true).Count >= 3, "Incomplete 16-angle/garment art blocks release");
            var bad = catalog.baseline.Copy(); bad.selections = bad.selections.Where(s => s.slot != AppearanceSlot.Upper).ToArray(); bad.dependencyHash = null;
            Check(AppearanceValidation.Check(catalog, bad).Any(e => e.Contains("필수 슬롯")), "Required garment cannot be omitted");
            bad = catalog.baseline.Copy(); bad.selections[0].paletteId = "arbitrary"; bad.dependencyHash = null;
            Check(AppearanceValidation.Check(catalog, bad).Count > 0, "Unknown palette rejected");
            bad = catalog.baseline.Copy(); bad.weaponFamily = "spear"; bad.dependencyHash = null;
            Check(AppearanceValidation.Check(catalog, bad).Any(e => e.Contains("계열")), "Weapon family mismatch rejected");
            bad = catalog.baseline.Copy(); bad.dependencyHash = "changed";
            Check(AppearanceValidation.Check(catalog, bad).Any(e => e.Contains("해시")), "Tampered snapshot rejected");
            damaged = UnityEngine.Object.Instantiate(catalog);
            damaged.parts[0].pieces[0].frames[0] = null;
            Check(AppearanceValidation.Check(damaged, damaged.baseline).Any(e => e.Contains("Sprite")), "Missing pose sprite rejected");
            Check(catalog.parts[0].pieces[0].frames[0] != null, "Validation fixture does not mutate shared catalog");
            var draft = new AppearanceDraft { baseline = catalog.baseline.Copy(), overrides = new[] {
                new PartSelection { slot = AppearanceSlot.Upper, mode = Game.Characters.SelectionMode.Empty } } };
            bool blocked = false; try { AppearanceValidation.Resolve(draft); } catch (InvalidOperationException) { blocked = true; }
            Check(blocked, "Draft required-slot empty rejected");
            var recipe = catalog.baseline.Copy(); recipe.dependencyHash = null;
            recipe.selections.First(s => s.slot == AppearanceSlot.Upper).paletteId = "cool";
            recipe.selections.First(s => s.slot == AppearanceSlot.Lower).paletteId = "warm";
            Check(await actor.ApplyAsync(recipe), "Independent upper/lower palettes assemble");
            Check(catalog.baseline.selections.All(s => s.paletteId == "neutral"), "Assembly leaves baseline immutable");
            Check(provider.ActiveLeases == report.referenceBaseline + 4, "One lease per selected part");
            int renders = root.GetComponentsInChildren<SpriteRenderer>().Length;
            Check(renders == 8, "Eight renderer pieces, shared sprites, no whole-character bake");
            for (int i = 0; i < catalog.frameCount; i++) actor.RenderFrame(i, catalog.frameCount - i - 1);
            Check(actor.IsReady, "All 432 upper/lower frame combinations sampled");
            for (int i = 0; i < 20; i++) actor.RenderFrame(i, i);
            long before = GC.GetAllocatedBytesForCurrentThread();
            for (int i = 0; i < 10000; i++) actor.RenderFrame(i % catalog.frameCount, i % catalog.frameCount);
            report.renderAllocatedBytes = GC.GetAllocatedBytesForCurrentThread() - before;
            Check(report.renderAllocatedBytes == 0, "10,000 presentation samples allocate 0 managed bytes on test thread");
            Check(!await actor.ApplyAsync(bad) && actor.AppliedRecipe.selections.First(s => s.slot == AppearanceSlot.Upper).paletteId == "cool",
                "Invalid replacement retains previous appearance");
            var delayed = new DelayedProvider(); actor.Provider = delayed;
            var pending = actor.ApplyAsync(catalog.baseline);
            actor.Provider = provider;
            Check(await actor.ApplyAsync(recipe), "Newer request replaces pending request");
            bool released = false;
            delayed.completion.SetResult(new VisualLease(catalog.parts[0], () => released = true));
            Check(!await pending, "Late request cannot overwrite newer appearance");
            await Task.Delay(20);
            Check(released, "Late provider completion returns its lease");
            var pooled = new DelayedProvider(); actor.Provider = pooled;
            var pooledRequest = actor.ApplyAsync(catalog.baseline);
            actor.Release();
            bool poolLeaseReleased = false;
            pooled.completion.SetResult(new VisualLease(catalog.parts[0], () => poolLeaseReleased = true));
            Check(!await pooledRequest && !actor.IsReady, "Pool return invalidates pending generation");
            await Task.Delay(20);
            Check(poolLeaseReleased, "Pool return releases late acquired resource");
            actor.Provider = provider;
            Check(await actor.ApplyAsync(recipe), "Current appearance restored for timeout test");
            var stalled = new DelayedProvider(); actor.Provider = stalled;
            float began = Time.realtimeSinceStartup;
            Check(!await actor.ApplyAsync(catalog.baseline) && Time.realtimeSinceStartup - began >= 9.5f && actor.IsReady,
                "Stalled load fails at realtime timeout and preserves current appearance");
            bool timeoutLeaseReleased = false;
            stalled.completion.SetResult(new VisualLease(catalog.parts[0], () => timeoutLeaseReleased = true));
            await Task.Delay(20);
            Check(timeoutLeaseReleased, "Timed-out provider completion returns its lease");
            actor.Provider = provider;
            for (int i = 0; i < 100; i++) CheckSwap(await actor.ApplyAsync(i % 2 == 0 ? catalog.baseline : recipe));
            Check(provider.ActiveLeases == report.referenceBaseline + 4, "100 swaps retain exactly one current set of leases");
            actor.Release();
            Check(provider.ActiveLeases == report.referenceBaseline, "Pool release returns all owned references");
            Check(await actor.ApplyAsync(recipe), "Released actor can be reused");
            actor.Release();
            var sprites = catalog.parts.SelectMany(p => p.pieces).SelectMany(p => p.frames);
            Check(sprites.All(s => Mathf.Abs(s.pivot.x - Mathf.Round(s.pivot.x)) < .001f && Mathf.Abs(s.pivot.y - Mathf.Round(s.pivot.y)) < .001f),
                "Cropped sprites retain integer pixel pivots");
            Check(sprites.All(s => s.pixelsPerUnit == 32), "All imported pieces use 32 PPU");
        }
        catch (Exception e) { report.failure = e.ToString(); }
        finally
        {
            actor.Release(); UnityEngine.Object.DestroyImmediate(root); UnityEngine.Object.DestroyImmediate(material);
            if (damaged != null) UnityEngine.Object.DestroyImmediate(damaged);
            report.referenceAfter = provider.ActiveLeases;
        }
        Directory.CreateDirectory("Screenshots/CharacterAssembly");
        string json = JsonUtility.ToJson(report, true);
        File.WriteAllText("Screenshots/CharacterAssembly/AssemblyValidation.json", json);
        return json;
    }
    private static void CheckSwap(bool ok) { if (!ok) throw new Exception("Swap failed"); }
}
