-- Export existing authored layers without changing the original Aseprite file.
local source = 'Assets/Art/Characters/MannequinMotion/MannequinMotion.aseprite'
local root = 'Assets/Art/Characters/Assembly/Sheets/'
app.fs.makeAllDirectories(root)
local spr = app.open(source)
assert(spr and #spr.frames == 432, 'Expected the 432-frame mannequin source')
local groups = {head={'Head'}, torso={'Torso'}, fararm={'FarArm'}, neararm={'NearArm'},
 legs={'FarLeg','NearLeg'}, hands={'Hands'}, weapon={'Weapon'}, shadow={'Shadow'}}
for name, layers in pairs(groups) do
 local sheet = Image(2048,3456,ColorMode.RGB)
 for f=1,#spr.frames do
  for _,wanted in ipairs(layers) do
   local found=false
   for _,layer in ipairs(spr.layers) do
    if layer.name==wanted then
     found=true
     local cel=layer:cel(f)
     if cel then sheet:drawImage(cel.image,Point(((f-1)%16)*128+cel.position.x,math.floor((f-1)/16)*128+cel.position.y)) end
    end
   end
   assert(found,'Missing layer '..wanted)
  end
 end
 sheet:saveAs(root..name..'.png')
end
spr:close()
print('Exported eight independent assembly sheets. Source preserved.')
